# Higgs assessment verifier0.1.2

Obtain this software and its detached identity outside the assessment. Use Python3.12. No InvenTree, pip installation, network or model is required. Host modules are included for source-identity equality but not imported by this CLI.

```sh
python3 -B verify_assessment.py --assessment /path/to/extracted-assessment --out /path/to/new-output --level decision
```

Output must be new and separate from the assessment. Exit0 means requested level met, exit1 NOT_VERIFIED, exit3 historical engine reproduction only when full verification never existed. A missing/unavailable historical verifier never silently falls back. Structured failures include receipt_saved=false when storage prevents persistence. Inspect assessment_version, executing_verifier_version and assurance_details.

Engine reproduction intentionally checks less than full recorded-decision verification. Only new0.1.2 full decisions check deterministic SUMMARY.md. The exact archived0.1.1 ZIP is included and externally pinned for old contracts; it remains byte-identical. See VERIFIER_COMPATIBILITY.md and ASSURANCE_CONTRACT.md. Runtime/member pins are external to the assessment; the assessment's recorded manifest is not authority. No physical/manufacturer/authorship authenticity or independent engineering approval is implied. Proposed licensing and inherited source-use qualifications remain; local candidate, no publication authorization.
