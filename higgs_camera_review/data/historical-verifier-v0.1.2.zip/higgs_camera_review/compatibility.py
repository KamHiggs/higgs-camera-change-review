"""Explicit dispatch to the unchanged historical verifier; never newer semantics."""
import json
import subprocess
import sys
import zipfile
import io
import hashlib
from pathlib import Path
from .errors import ReviewFailure

HISTORICAL_SHA = '96f99c16314a57e7c1eb6c6e769e3cae7af2e0cb4081b5423eb23e3554b6bfb6'
HISTORICAL_ARCHIVE = Path(__file__).parent / 'data/historical-verifier-v0.1.1.zip'


def compatibility_info(version):
    if version not in ('0.1.0','0.1.1','0.1.2'):
        return {'assessment_version':version,'available':False,'code':'ASSESSMENT_VERSION'}
    from .contract import software_identity
    historical=version!='0.1.2'
    available=True
    if historical:
        try:available=hashlib.sha256(HISTORICAL_ARCHIVE.read_bytes()).hexdigest()==HISTORICAL_SHA
        except OSError:available=False
    return {'assessment_version':version,'dispatcher_software_sha256':software_identity(),'executing_verifier_version':'0.1.1' if historical else '0.1.2',
            'available':available,'historical_verifier_archive_sha256':HISTORICAL_SHA if historical else None,
            'full_decision_available':available and version!='0.1.0',
            'summary_md_semantically_checked':version=='0.1.2',
            'code':'AVAILABLE' if available else 'HISTORICAL_VERIFIER_UNAVAILABLE',
            'meaning':'Historical semantics preserved; no newer guarantees inherited' if historical else 'Versioned0.1.2 decision contract'}


def run_historical(assessment,out,level,version,env):
    try:raw=HISTORICAL_ARCHIVE.read_bytes()
    except OSError as exc:
        raise ReviewFailure('CONFIGURATION_ERROR','HISTORICAL_VERIFIER_UNAVAILABLE','Verification unavailable for this historical contract') from exc
    if hashlib.sha256(raw).hexdigest()!=HISTORICAL_SHA:
        raise ReviewFailure('INTEGRITY_ERROR','HISTORICAL_VERIFIER_IDENTITY','Historical verifier does not match the externally pinned package')
    target=out/'historical-verifier'
    # Only a byte-exact, externally pinned archive may supply executable code.
    with zipfile.ZipFile(io.BytesIO(raw)) as z:z.extractall(target)
    proc=subprocess.run([sys.executable,'-B',str(target/'verify_assessment.py'),'--assessment',str(assessment),
                         '--out',str(out/'historical-result'),'--level',level],cwd=out,env=env,capture_output=True,text=True,timeout=180)
    (out/'historical.stdout').write_text(proc.stdout);(out/'historical.stderr').write_text(proc.stderr)
    try:result=json.loads(proc.stdout)
    except ValueError as exc:
        raise ReviewFailure('PROCESS_FAILURE','HISTORICAL_VERIFIER_FAILED','Historical verifier did not return a structured result; diagnostics retained') from exc
    if not isinstance(result,dict) or result.get('assurance_level') not in ('NOT_VERIFIED','REPRODUCED_ENGINE_OUTPUT','VERIFIED_RECORDED_DECISION'):
        raise ReviewFailure('PROCESS_FAILURE','HISTORICAL_VERIFIER_FAILED','Historical verifier returned an unsupported result')
    expected_exit=1 if result['assurance_level']=='NOT_VERIFIED' else (3 if level=='decision' and result['assurance_level']!='VERIFIED_RECORDED_DECISION' else 0)
    if proc.returncode!=expected_exit:
        raise ReviewFailure('PROCESS_FAILURE','HISTORICAL_VERIFIER_EXIT','Historical verifier exit disagrees with its result')
    result.update(assessment_version=version,executing_verifier_version='0.1.1',dispatcher_version='0.1.2',historical_verifier_archive_sha256=HISTORICAL_SHA,
                  assurance_details={'semantic_contract':version,'summary_md_semantically_checked':False,'v012_format_guarantee':False,
                  'current_intake_checks':'Complete recorded-file coverage and minimum structure checked before historical dispatch; not retrospective semantic assurance',
                  'not_authenticated':['authorship','historical time','physical identity','manufacturer truth','engineering approval']})
    return result
