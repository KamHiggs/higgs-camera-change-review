# Verifier compatibility matrix — frozen before implementation

| Assessment | Applicable executor | Engine reproduction | Full recorded decision | Human summary / file-format assurance |
|---|---|---|---|---|
| 0.1.0 | Exact archived verifier 0.1.1 | Supported | Did not exist; decision request returns exit3 with weaker assurance | No retroactive0.1.2 guarantees |
| 0.1.1 | Exact archived verifier 0.1.1 | Supported | Original0.1.1 semantics | No deterministic SUMMARY.md or0.1.2 allowlist guarantee |
| 0.1.2 | Verifier0.1.2 | Supported | New0.1.2 semantics | Complete coverage and format permission; full decision additionally checks deterministic SUMMARY.md |

The0.1.2 entry point is a dispatcher for older versions. It executes only the byte-exact archived0.1.1 verifier pinned by SHA-256 `96f99c16314a57e7c1eb6c6e769e3cae7af2e0cb4081b5423eb23e3554b6bfb6`. That archived ZIP is unchanged and ships in data/. No historical source or SUMMARY.md is regenerated. If the archive is absent, report HISTORICAL_VERIFIER_UNAVAILABLE; if it is replaced, refuse its identity. Never substitute new semantic rules for historical ones.

Current coverage/structural intake checks can reject malformed old records before dispatch. Passing that screen does not retroactively certify their prose or upgrade their original semantic contract. The UI reports executor version, dispatcher software identity, availability and historical package hash. Actual verification results retain the executor software hash and applicable contract.
