# Assessment and assurance contract 0.1.2

**Integrity ≠ authority ≠ truth.** The recorded assessment manifest describes file identities in this package. It is not an independent pin, proof of authorship, permission or approval. Runtime/software pins come from the separately obtained verifier. A consistently false set of inventory declarations can remain internally consistent.

## File coverage and permission are different checks

Coverage enumerates every regular payload file except the single root-relative ASSESSMENT_MANIFEST.json. A nested file with that basename is ordinary payload. Missing/unlisted/mutated files fail coverage. Export freezes and rechecks accepted bytes, then writes exactly payload membership plus that root manifest.

The closed0.1.2 file set is implemented in assessment_format.py (BASE_REQUIRED, NEW_REQUIRED, ENGINE_FILES, OPTIONAL_ANCILLARY). This module is part of the software identity. Output files are conditional because an engine refusal need not produce a successful analysis report. Missing files needed for reproduction/decision agreement still cause verification refusal.

| Category | Members | Assurance |
|---|---|---|
| Decision chain | snapshot, typed inputs, recorded binding, mapping result/trace, runtime provenance, projection, processes, summary JSON | Minimum structures first; defined identity/decision fields reconstructed for full decision verification |
| Pinned dependency | dependency/runtime-subset.zip and subset_identity.json | External runtime/member pins; declaration fields checked, descriptive meaning text not authenticated |
| Engine outputs | Explicit generated-case, applicability, materialization trace, analysis report/result/HTML/revalidation plan, questions result/explanation paths | Exact engine output byte reproduction at either level; not independent physical validation |
| Human projection | SUMMARY.md | Required in new format; deterministic reconstruction checked only at full-decision level |
| Distribution helper | replay.py | Must match the verifier's pinned helper bytes; never executed by verification |
| Optional ancillary | ancillary/operator-note.txt only, UTF-8, at most65536 bytes | MANIFEST_VERIFIED_BUT_NOT_SEMANTICALLY_VERIFIED; exact path listed in result |
| Forbidden | Everything outside the explicit set, including ENGINEERING_APPROVAL.md and nested manifest files | Format refusal even when correctly manifest-covered |

An explicitly listed nested manifest file can pass the coverage helper while failing format permission. That is intentional. The approved optional note is not a route to approval or an engineering claim. No general attachment system is provided.

## Levels

REPRODUCED_ENGINE_OUTPUT: coverage, permitted format/minimum shapes and pinned runtime, then reproduction of saved projection output bytes. It does not establish snapshot-to-projection consistency or correctness of summary JSON/SUMMARY.md. Its result explicitly lists those exclusions.

VERIFIED_RECORDED_DECISION: additionally reconstruct raw inputs and recorded bindings, mapper projection, deterministic engine result and versioned summary JSON; compare the deterministic SUMMARY.md generated from that verified JSON. A contradictory human summary fails this level. Missing required SUMMARY.md fails new-format admission.

Non-semantic fields are not authenticated: inventory friendly names/role, snapshot.audit, summary creation ID/time, process PID/time/command/stream hashes, runtime-provenance relationship prose, subset-identity meaning prose. Hash coverage of these bytes is not chronology/authorship authentication. Results enumerate exclusions. Historical contracts retain their own exclusions and exact executor.

No level authenticates a physical device, manufacturer truth, authorship, deployment approval or general engineering correctness. Identical algorithms can share a modeling mistake.

## Failure and storage contract

Minimum versioned document shapes are checked before semantic access. Malformed but rehashed records are retained, excluded from ordinary history, and refused on direct open/export. Local operator diagnostics explain exclusion; no repair occurs.

FPS is an ASCII decimal string of1–32 characters with numeric value1–1000. Leading zeros are accepted within that length limit (`045`→45); raw spelling remains recorded. Create and comparison use the same parser. Invalid/long client input is a controlled client error, not a PROCESS_FAILURE.

Host verification writes only to HIGGS_STATE_ROOT/verification-runs/<new-id>. No sibling output root is implicit. Setup and final result publication are inside structured failure handling. Receipts are written to a temporary file and renamed; failed finalization returns NOT_VERIFIED/STORAGE_FAILURE/receipt_saved=false. A failing filesystem cannot be promised a saved receipt. CLI still reports structured stdout when its output directory cannot be written. Host server/storage faults use controlled5xx.

Viewer advisory computation remains allowed; inventory mutation still requires change permission. Retention is an operator responsibility; no quotas or generalized roles are added.
