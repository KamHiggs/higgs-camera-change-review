# Revalidation plan

**Proposed, unapproved, not hardware-validated.**

Status: insufficient_evidence

Retain all original pre-change records. No hardware test has been created or run by this application.

## Variant LINE-FAST

Resolve the listed missing facts/blockers before selecting any configuration; no executable proposal

Exact configuration:
```json
null
```

- timing: test the exact configuration, record observations and guaranteed source bounds as separate evidence.
- resolution: test the exact configuration, record observations and guaranteed source bounds as separate evidence.
- throughput: test the exact configuration, record observations and guaranteed source bounds as separate evidence.
- power: test the exact configuration, record observations and guaranteed source bounds as separate evidence.
- voltage: test the exact configuration, record observations and guaranteed source bounds as separate evidence.
- transport: test the exact configuration, record observations and guaranteed source bounds as separate evidence.
- timestamp_adapter: test the exact configuration, record observations and guaranteed source bounds as separate evidence.

Retain evidence: SYN-TEST-FLIR-SAMPLE, SYN-TEST-LEGACY-FAST

## Variant LINE-SLOW

Resolve the listed missing facts/blockers before selecting any configuration; no executable proposal

Exact configuration:
```json
null
```

- timing: test the exact configuration, record observations and guaranteed source bounds as separate evidence.
- resolution: test the exact configuration, record observations and guaranteed source bounds as separate evidence.
- throughput: test the exact configuration, record observations and guaranteed source bounds as separate evidence.
- power: test the exact configuration, record observations and guaranteed source bounds as separate evidence.
- voltage: test the exact configuration, record observations and guaranteed source bounds as separate evidence.
- transport: test the exact configuration, record observations and guaranteed source bounds as separate evidence.
- timestamp_adapter: test the exact configuration, record observations and guaranteed source bounds as separate evidence.

Retain evidence: SYN-TEST-FLIR-SAMPLE, SYN-TEST-LEGACY-FAST

## Evidence required / established blockers

```json
[
  {
    "camera_id": "CAM-BASLER",
    "variant_id": "LINE-FAST",
    "missing": [
      "frame_rate: missing/conflicting max_fps",
      "power: missing/conflicting power_W"
    ],
    "established_blockers": []
  },
  {
    "camera_id": "CAM-BASLER",
    "variant_id": "LINE-SLOW",
    "missing": [
      "frame_rate: missing/conflicting max_fps",
      "power: missing/conflicting power_W"
    ],
    "established_blockers": []
  },
  {
    "camera_id": "CAM-FLIR",
    "variant_id": "LINE-FAST",
    "missing": [
      "timing: missing/conflicting timestamp_jitter_bound_ms"
    ],
    "established_blockers": []
  },
  {
    "camera_id": "CAM-FLIR",
    "variant_id": "LINE-SLOW",
    "missing": [
      "timing: missing/conflicting timestamp_jitter_bound_ms"
    ],
    "established_blockers": []
  },
  {
    "camera_id": "CAM-ALLIED",
    "variant_id": "LINE-FAST",
    "missing": [
      "power: missing/conflicting power_W"
    ],
    "established_blockers": [
      "frame_rate: established failure"
    ]
  },
  {
    "camera_id": "CAM-ALLIED",
    "variant_id": "LINE-SLOW",
    "missing": [
      "power: missing/conflicting power_W"
    ],
    "established_blockers": []
  }
]
```

Selection evidence:
```json
[]
```

If a known constraint fails, an alternative guaranteed specification meeting that named limit would change the conclusion. Changing hardware, required FPS, speed or requirements is outside the permitted plan and is only a counterfactual.

After both software and hardware revalidation, obtain explicit human engineering approval. A saved PASS, a source document or this report is not approval.
