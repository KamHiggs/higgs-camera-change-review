Candidate: CAM-FLIR. Current decision: insufficient_evidence.

Analysis: supported.

shared: 0 <= guaranteed jitter <= 2/5 ms, inclusive; cost 2 synthetic points; if feasible: create first feasible plan.

per_variant: 0 <= guaranteed jitter <= 2/5 ms, inclusive; cost 5 synthetic points; if feasible: create first feasible plan.

j = 0 ms: create first feasible plan; best target policy shared, 2 points. Conditional mathematics only.

0 < j < 2/5 ms: create first feasible plan; best target policy shared, 2 points. Conditional mathematics only.

j = 2/5 ms: create first feasible plan; best target policy shared, 2 points. Conditional mathematics only.

2/5 < j ms: no target plan. Conditional mathematics only.

Ask: Ask the integration owner for an applicable guaranteed upper bound for CAM-FLIR timestamp jitter in ms, tied to the declared event, clock behavior and variant conditions. The slot is synthetic integration characterization, not a recovered manufacturer guarantee. Finite samples, typical values and PASS statements remain insufficient. If such a guarantee cannot be justified, retain unknown or revisit model applicability. Voltage compatibility remains outside this bounded result.

Voltage compatibility remains unknown outside this bounded subsystem. No jitter guarantee establishes full replacement suitability.

Synthetic model only; facts are supplied, not independently authenticated.

Cost comparison covers established plans only; unresolved other candidates can still matter.

Representative previews are hypothetical witnesses, not a proof of encoding over a whole region.

Mathematical conditions are not a guaranteed executable configuration. No supplier fact, deployment approval, or hardware qualification was created.
