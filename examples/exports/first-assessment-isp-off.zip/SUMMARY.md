# Higgs camera assessment — recorded decision

Assessment contract: higgs-assessment-v0.1.2

## Status

CONDITIONAL_EVIDENCE_QUESTION

Camera: CAM-FLIR

Advisory result — no deployment approval.

Real source captures; synthetic installation, requirements, timing assumptions and cost points. No hardware or deployment approval.

## Reason and counts

```json
[]
```

## Counts

```json
{
  "condition_unresolved_evidence_rows": 0,
  "established_constraint_failures": 0,
  "normally_inapplicable_rows": 1,
  "quarantined_evidence_rows": 0,
  "unknown_constraint_evaluations": 2,
  "unresolved_premises": 0
}
```

## Established blockers

```json
[]
```

## Unknown constraints

```json
[
  {
    "comparison": "minimum achievable worst-case error <= limit",
    "constraint": "timing",
    "limit": 1,
    "locators": [
      {
        "field_present": true,
        "locator": "/data/timestamp_jitter_bound_ms",
        "requested_locator": "/data/timestamp_jitter_bound_ms",
        "source_id": "GEN-CAM-FLIR"
      },
      {
        "field_present": true,
        "locator": "/data/timestamp_bias_ms_by_variant/LINE-FAST",
        "requested_locator": "/data/timestamp_bias_ms_by_variant/LINE-FAST",
        "source_id": "GEN-CAM-FLIR"
      },
      {
        "field_present": true,
        "locator": "/data/speed_m_s",
        "requested_locator": "/data/speed_m_s",
        "source_id": "SYN-REQ-LINE-FAST"
      },
      {
        "field_present": true,
        "locator": "/data/max_registration_error_mm",
        "requested_locator": "/data/max_registration_error_mm",
        "source_id": "SYN-REQ-LINE-FAST"
      },
      {
        "field_present": true,
        "locator": "/data/host_jitter_bound_ms",
        "requested_locator": "/data/host_jitter_bound_ms",
        "source_id": "SYN-REQ-LINE-FAST"
      }
    ],
    "missing_fields": [
      "timestamp_jitter_bound_ms"
    ],
    "source_ids": [
      "GEN-CAM-FLIR",
      "SYN-REQ-LINE-FAST"
    ],
    "status": "unknown",
    "value": null,
    "variant_id": "LINE-FAST"
  },
  {
    "comparison": "minimum achievable worst-case error <= limit",
    "constraint": "timing",
    "limit": 0.5,
    "locators": [
      {
        "field_present": true,
        "locator": "/data/timestamp_jitter_bound_ms",
        "requested_locator": "/data/timestamp_jitter_bound_ms",
        "source_id": "GEN-CAM-FLIR"
      },
      {
        "field_present": true,
        "locator": "/data/timestamp_bias_ms_by_variant/LINE-SLOW",
        "requested_locator": "/data/timestamp_bias_ms_by_variant/LINE-SLOW",
        "source_id": "GEN-CAM-FLIR"
      },
      {
        "field_present": true,
        "locator": "/data/speed_m_s",
        "requested_locator": "/data/speed_m_s",
        "source_id": "SYN-REQ-LINE-SLOW"
      },
      {
        "field_present": true,
        "locator": "/data/max_registration_error_mm",
        "requested_locator": "/data/max_registration_error_mm",
        "source_id": "SYN-REQ-LINE-SLOW"
      },
      {
        "field_present": true,
        "locator": "/data/host_jitter_bound_ms",
        "requested_locator": "/data/host_jitter_bound_ms",
        "source_id": "SYN-REQ-LINE-SLOW"
      }
    ],
    "missing_fields": [
      "timestamp_jitter_bound_ms"
    ],
    "source_ids": [
      "GEN-CAM-FLIR",
      "SYN-REQ-LINE-SLOW"
    ],
    "status": "unknown",
    "value": null,
    "variant_id": "LINE-SLOW"
  }
]
```

## Decision-changing evidence

```json
{
  "analysis_scope": "bounded_non_voltage_synthetic",
  "cartridge_id": "camera",
  "cartridge_version": "0.1.2",
  "decision_status": "conditional_evidence_analysis",
  "deployment_qualified": false,
  "excluded_constraints": [
    "voltage"
  ],
  "execution_status": "completed",
  "full_camera_compatibility": false,
  "human_approval_recorded": false,
  "interface_version": "higgs.python-cognimap/1",
  "operation": "decision_questions",
  "qualification": "Every plan and evidence question is conditional on this non-voltage subsystem; voltage still requires independent resolution.",
  "request_identity": "a3296426e784c0b3d5a8e9190e0481afd6ae5697bfc51e001cf7f0734e3094ec",
  "result": {
    "analysis_scope": "bounded_non_voltage_synthetic",
    "analysis_status": "supported",
    "base_input_identity": "cb0cd8d9e4e98b76c1442499a81c6ad936b9ece68cc9e2f68ddf89efb717f110",
    "base_unchanged": true,
    "blocker_details": [],
    "blockers": [],
    "cartridge_version": "0.1.2",
    "current_decision": {
      "cartridge_version": "0.1.2",
      "cost_points_exact": null,
      "decision_status": "insufficient_evidence",
      "error": null,
      "execution_status": "completed",
      "input_identity": "cb0cd8d9e4e98b76c1442499a81c6ad936b9ece68cc9e2f68ddf89efb717f110",
      "request_identity": "48a133efeb904c499d2247d48d6bca4f71ae2ecbaeed8ce4f18f0b9441b9db4c",
      "selected_plan": null
    },
    "decision_status": "conditional_evidence_analysis",
    "deployment_qualified": false,
    "derivation": [
      {
        "a_ms": {
          "$rational": [
            "2",
            "5"
          ]
        },
        "bias_ms": 0,
        "host_jitter_ms": {
          "$rational": [
            "1",
            "10"
          ]
        },
        "limit_mm": 1,
        "lower_at_zero_ms": {
          "$rational": [
            "-2",
            "5"
          ]
        },
        "source_locators": [
          {
            "field_present": true,
            "locator": "/data/timestamp_jitter_bound_ms",
            "requested_locator": "/data/timestamp_jitter_bound_ms",
            "source_id": "GEN-CAM-FLIR"
          },
          {
            "field_present": true,
            "locator": "/data/timestamp_bias_ms_by_variant/LINE-FAST",
            "requested_locator": "/data/timestamp_bias_ms_by_variant/LINE-FAST",
            "source_id": "GEN-CAM-FLIR"
          },
          {
            "field_present": true,
            "locator": "/data/speed_m_s",
            "requested_locator": "/data/speed_m_s",
            "source_id": "SYN-REQ-LINE-FAST"
          },
          {
            "field_present": true,
            "locator": "/data/max_registration_error_mm",
            "requested_locator": "/data/max_registration_error_mm",
            "source_id": "SYN-REQ-LINE-FAST"
          },
          {
            "field_present": true,
            "locator": "/data/host_jitter_bound_ms",
            "requested_locator": "/data/host_jitter_bound_ms",
            "source_id": "SYN-REQ-LINE-FAST"
          }
        ],
        "speed_m_s": 2,
        "supplied_variant_operating_conditions": {
          "field_of_view_mm": 30,
          "host_jitter_bound_ms": {
            "$rational": [
              "1",
              "10"
            ]
          },
          "link_capacity_MB_s": 300,
          "max_mm_per_pixel": {
            "$rational": [
              "1",
              "50"
            ]
          },
          "max_registration_error_mm": 1,
          "power_budget_W": {
            "$rational": [
              "16",
              "5"
            ]
          },
          "required_fps": 45,
          "speed_m_s": 2,
          "supply_voltage_V": 5,
          "transport": "USB3-Vision"
        },
        "upper_at_zero_ms": {
          "$rational": [
            "2",
            "5"
          ]
        },
        "variant_id": "LINE-FAST",
        "zero_speed": false
      },
      {
        "a_ms": {
          "$rational": [
            "9",
            "10"
          ]
        },
        "bias_ms": 0,
        "host_jitter_ms": {
          "$rational": [
            "1",
            "10"
          ]
        },
        "limit_mm": {
          "$rational": [
            "1",
            "2"
          ]
        },
        "lower_at_zero_ms": {
          "$rational": [
            "-9",
            "10"
          ]
        },
        "source_locators": [
          {
            "field_present": true,
            "locator": "/data/timestamp_jitter_bound_ms",
            "requested_locator": "/data/timestamp_jitter_bound_ms",
            "source_id": "GEN-CAM-FLIR"
          },
          {
            "field_present": true,
            "locator": "/data/timestamp_bias_ms_by_variant/LINE-SLOW",
            "requested_locator": "/data/timestamp_bias_ms_by_variant/LINE-SLOW",
            "source_id": "GEN-CAM-FLIR"
          },
          {
            "field_present": true,
            "locator": "/data/speed_m_s",
            "requested_locator": "/data/speed_m_s",
            "source_id": "SYN-REQ-LINE-SLOW"
          },
          {
            "field_present": true,
            "locator": "/data/max_registration_error_mm",
            "requested_locator": "/data/max_registration_error_mm",
            "source_id": "SYN-REQ-LINE-SLOW"
          },
          {
            "field_present": true,
            "locator": "/data/host_jitter_bound_ms",
            "requested_locator": "/data/host_jitter_bound_ms",
            "source_id": "SYN-REQ-LINE-SLOW"
          }
        ],
        "speed_m_s": {
          "$rational": [
            "1",
            "2"
          ]
        },
        "supplied_variant_operating_conditions": {
          "field_of_view_mm": 30,
          "host_jitter_bound_ms": {
            "$rational": [
              "1",
              "10"
            ]
          },
          "link_capacity_MB_s": 300,
          "max_mm_per_pixel": {
            "$rational": [
              "1",
              "50"
            ]
          },
          "max_registration_error_mm": {
            "$rational": [
              "1",
              "2"
            ]
          },
          "power_budget_W": {
            "$rational": [
              "16",
              "5"
            ]
          },
          "required_fps": 30,
          "speed_m_s": {
            "$rational": [
              "1",
              "2"
            ]
          },
          "supply_voltage_V": 5,
          "transport": "USB3-Vision"
        },
        "upper_at_zero_ms": {
          "$rational": [
            "9",
            "10"
          ]
        },
        "variant_id": "LINE-SLOW",
        "zero_speed": false
      }
    ],
    "evidence_request": {
      "evidence_source_role": "integration_owner",
      "evidence_standard": "Applicable guaranteed upper bound; a typical value, finite sample or PASS is insufficient",
      "field": "timestamp_jitter_bound_ms",
      "locator": "/data/timestamp_jitter_bound_ms",
      "operating_conditions": [
        {
          "a_ms": {
            "$rational": [
              "2",
              "5"
            ]
          },
          "bias_ms": 0,
          "host_jitter_ms": {
            "$rational": [
              "1",
              "10"
            ]
          },
          "limit_mm": 1,
          "lower_at_zero_ms": {
            "$rational": [
              "-2",
              "5"
            ]
          },
          "source_locators": [
            {
              "field_present": true,
              "locator": "/data/timestamp_jitter_bound_ms",
              "requested_locator": "/data/timestamp_jitter_bound_ms",
              "source_id": "GEN-CAM-FLIR"
            },
            {
              "field_present": true,
              "locator": "/data/timestamp_bias_ms_by_variant/LINE-FAST",
              "requested_locator": "/data/timestamp_bias_ms_by_variant/LINE-FAST",
              "source_id": "GEN-CAM-FLIR"
            },
            {
              "field_present": true,
              "locator": "/data/speed_m_s",
              "requested_locator": "/data/speed_m_s",
              "source_id": "SYN-REQ-LINE-FAST"
            },
            {
              "field_present": true,
              "locator": "/data/max_registration_error_mm",
              "requested_locator": "/data/max_registration_error_mm",
              "source_id": "SYN-REQ-LINE-FAST"
            },
            {
              "field_present": true,
              "locator": "/data/host_jitter_bound_ms",
              "requested_locator": "/data/host_jitter_bound_ms",
              "source_id": "SYN-REQ-LINE-FAST"
            }
          ],
          "speed_m_s": 2,
          "supplied_variant_operating_conditions": {
            "field_of_view_mm": 30,
            "host_jitter_bound_ms": {
              "$rational": [
                "1",
                "10"
              ]
            },
            "link_capacity_MB_s": 300,
            "max_mm_per_pixel": {
              "$rational": [
                "1",
                "50"
              ]
            },
            "max_registration_error_mm": 1,
            "power_budget_W": {
              "$rational": [
                "16",
                "5"
              ]
            },
            "required_fps": 45,
            "speed_m_s": 2,
            "supply_voltage_V": 5,
            "transport": "USB3-Vision"
          },
          "upper_at_zero_ms": {
            "$rational": [
              "2",
              "5"
            ]
          },
          "variant_id": "LINE-FAST",
          "zero_speed": false
        },
        {
          "a_ms": {
            "$rational": [
              "9",
              "10"
            ]
          },
          "bias_ms": 0,
          "host_jitter_ms": {
            "$rational": [
              "1",
              "10"
            ]
          },
          "limit_mm": {
            "$rational": [
              "1",
              "2"
            ]
          },
          "lower_at_zero_ms": {
            "$rational": [
              "-9",
              "10"
            ]
          },
          "source_locators": [
            {
              "field_present": true,
              "locator": "/data/timestamp_jitter_bound_ms",
              "requested_locator": "/data/timestamp_jitter_bound_ms",
              "source_id": "GEN-CAM-FLIR"
            },
            {
              "field_present": true,
              "locator": "/data/timestamp_bias_ms_by_variant/LINE-SLOW",
              "requested_locator": "/data/timestamp_bias_ms_by_variant/LINE-SLOW",
              "source_id": "GEN-CAM-FLIR"
            },
            {
              "field_present": true,
              "locator": "/data/speed_m_s",
              "requested_locator": "/data/speed_m_s",
              "source_id": "SYN-REQ-LINE-SLOW"
            },
            {
              "field_present": true,
              "locator": "/data/max_registration_error_mm",
              "requested_locator": "/data/max_registration_error_mm",
              "source_id": "SYN-REQ-LINE-SLOW"
            },
            {
              "field_present": true,
              "locator": "/data/host_jitter_bound_ms",
              "requested_locator": "/data/host_jitter_bound_ms",
              "source_id": "SYN-REQ-LINE-SLOW"
            }
          ],
          "speed_m_s": {
            "$rational": [
              "1",
              "2"
            ]
          },
          "supplied_variant_operating_conditions": {
            "field_of_view_mm": 30,
            "host_jitter_bound_ms": {
              "$rational": [
                "1",
                "10"
              ]
            },
            "link_capacity_MB_s": 300,
            "max_mm_per_pixel": {
              "$rational": [
                "1",
                "50"
              ]
            },
            "max_registration_error_mm": {
              "$rational": [
                "1",
                "2"
              ]
            },
            "power_budget_W": {
              "$rational": [
                "16",
                "5"
              ]
            },
            "required_fps": 30,
            "speed_m_s": {
              "$rational": [
                "1",
                "2"
              ]
            },
            "supply_voltage_V": 5,
            "transport": "USB3-Vision"
          },
          "upper_at_zero_ms": {
            "$rational": [
              "9",
              "10"
            ]
          },
          "variant_id": "LINE-SLOW",
          "zero_speed": false
        }
      ],
      "source_id": "GEN-CAM-FLIR",
      "source_requirements": "Traceable authoritative integration evidence under declared operating premises; no vendor publication or obtainable proof is presumed.",
      "text": "Ask the integration owner for an applicable guaranteed upper bound for CAM-FLIR timestamp jitter in ms, tied to the declared event, clock behavior and variant conditions. The slot is synthetic integration characterization, not a recovered manufacturer guarantee. Finite samples, typical values and PASS statements remain insufficient. If such a guarantee cannot be justified, retain unknown or revisit model applicability. Voltage compatibility remains outside this bounded result.",
      "units": "ms",
      "upstream_origins": [
        {
          "applicability": "APPLICABLE",
          "capture_id": "CAP-SYN-040",
          "capture_sha256": "96673c967cd256c6897c3bf2fe8b555625d76e5d0f0ef82c4da9ef457ecb5102",
          "conditions": {
            "scenario": "fictional; no real measurement or guarantee"
          },
          "entry_id": "LEDGER-CAP-SYN-040",
          "evidence_class": "synthetic_guaranteed_bound",
          "lexical_value": "null",
          "locator": "/camera_supplements/CAM-FLIR/timestamp_jitter_bound_ms",
          "minimum_payload_MB_s": null,
          "normalized_exact": null,
          "origin": "synthetic",
          "source_document_sha256": "9437f7856dbd620d3315337f85abc81ef4e43c47f3a1147a5d5efc4a9f295a3b",
          "source_id": "SYN-integration_characterization",
          "units": "ms",
          "url": null
        }
      ]
    },
    "excluded_constraints": [
      "voltage"
    ],
    "executable_configuration_promised": false,
    "explanation": "Candidate: CAM-FLIR. Current decision: insufficient_evidence.\n\nAnalysis: supported.\n\nshared: 0 <= guaranteed jitter <= 2/5 ms, inclusive; cost 2 synthetic points; if feasible: create first feasible plan.\n\nper_variant: 0 <= guaranteed jitter <= 2/5 ms, inclusive; cost 5 synthetic points; if feasible: create first feasible plan.\n\nj = 0 ms: create first feasible plan; best target policy shared, 2 points. Conditional mathematics only.\n\n0 < j < 2/5 ms: create first feasible plan; best target policy shared, 2 points. Conditional mathematics only.\n\nj = 2/5 ms: create first feasible plan; best target policy shared, 2 points. Conditional mathematics only.\n\n2/5 < j ms: no target plan. Conditional mathematics only.\n\nAsk: Ask the integration owner for an applicable guaranteed upper bound for CAM-FLIR timestamp jitter in ms, tied to the declared event, clock behavior and variant conditions. The slot is synthetic integration characterization, not a recovered manufacturer guarantee. Finite samples, typical values and PASS statements remain insufficient. If such a guarantee cannot be justified, retain unknown or revisit model applicability. Voltage compatibility remains outside this bounded result.\n\nVoltage compatibility remains unknown outside this bounded subsystem. No jitter guarantee establishes full replacement suitability.\n\nSynthetic model only; facts are supplied, not independently authenticated.\n\nCost comparison covers established plans only; unresolved other candidates can still matter.\n\nRepresentative previews are hypothetical witnesses, not a proof of encoding over a whole region.\n\nMathematical conditions are not a guaranteed executable configuration. No supplier fact, deployment approval, or hardware qualification was created.",
    "full_camera_compatibility": false,
    "human_approval_recorded": false,
    "limitations": [
      "Voltage compatibility remains unknown outside this bounded subsystem. No jitter guarantee establishes full replacement suitability.",
      "Synthetic model only; facts are supplied, not independently authenticated.",
      "Cost comparison covers established plans only; unresolved other candidates can still matter.",
      "Representative previews are hypothetical witnesses, not a proof of encoding over a whole region."
    ],
    "model_id": "EC-SYNTHETIC-1.0",
    "policies": [
      {
        "boundary_outcomes": {
          "above": "mathematically_infeasible",
          "at": "mathematically_feasible",
          "below": "mathematically_feasible"
        },
        "controlling_constraints": {
          "lower_controlling_variants": [
            "LINE-FAST"
          ],
          "upper_controlling_variants": [
            "LINE-FAST"
          ]
        },
        "cost_points": 2,
        "decision_scope": "conditional_mathematics_only",
        "domain": {
          "kind": "bounded",
          "lower_inclusive": true,
          "lower_ms": {
            "$rational": [
              "0",
              "1"
            ]
          },
          "meaning": "nonnegative guaranteed jitter; mathematical domain only",
          "upper_inclusive": true,
          "upper_ms": {
            "$rational": [
              "2",
              "5"
            ]
          }
        },
        "effect_if_this_policy_feasible": "create_first_feasible_plan",
        "equation_reference": "docs/BOUNDED_ADAPTER_CONTRACT.md",
        "guarantee_required": true,
        "policy": "shared",
        "threshold_ms": {
          "$rational": [
            "2",
            "5"
          ]
        },
        "units": "ms"
      },
      {
        "boundary_outcomes": {
          "above": "mathematically_infeasible",
          "at": "mathematically_feasible",
          "below": "mathematically_feasible"
        },
        "controlling_constraints": {
          "limiting_variants": [
            "LINE-FAST"
          ]
        },
        "cost_points": 5,
        "decision_scope": "conditional_mathematics_only",
        "domain": {
          "kind": "bounded",
          "lower_inclusive": true,
          "lower_ms": {
            "$rational": [
              "0",
              "1"
            ]
          },
          "meaning": "nonnegative guaranteed jitter; mathematical domain only",
          "upper_inclusive": true,
          "upper_ms": {
            "$rational": [
              "2",
              "5"
            ]
          }
        },
        "effect_if_this_policy_feasible": "create_first_feasible_plan",
        "equation_reference": "docs/BOUNDED_ADAPTER_CONTRACT.md",
        "guarantee_required": true,
        "policy": "per_variant",
        "threshold_ms": {
          "$rational": [
            "2",
            "5"
          ]
        },
        "units": "ms"
      }
    ],
    "regions": [
      {
        "best_target_policy": "shared",
        "decision_scope": "conditional_mathematics_only",
        "effect": "create_first_feasible_plan",
        "feasible_target_policies": [
          "shared",
          "per_variant"
        ],
        "lower_inclusive": true,
        "lower_ms": {
          "$rational": [
            "0",
            "1"
          ]
        },
        "preview": {
          "assumed_guaranteed_jitter_ms": {
            "$rational": [
              "0",
              "1"
            ]
          },
          "assumption": {
            "base_source_id": "GEN-CAM-FLIR",
            "evidence_kind": "hypothetical_assumption",
            "field": "/data/timestamp_jitter_bound_ms",
            "hypothetical_value_ms": {
              "$rational": [
                "0",
                "1"
              ]
            },
            "promoted_to_fact": false,
            "source_id": "GEN-CAM-FLIR--HYP-1",
            "source_record": {
              "data": {
                "available": true,
                "bytes_per_pixel": 1,
                "image_height_px": 2048,
                "image_width_px": 2448,
                "max_fps": 73,
                "migration_cost_points": 2,
                "note": "Missing guaranteed jitter is deliberate. Typical 0.05 ms is synthetic sample context, not a guarantee and not from FLIR.",
                "power_W": 3,
                "supply_range_V": null,
                "timestamp_bias_ms_by_variant": {
                  "LINE-FAST": 0,
                  "LINE-SLOW": 0
                },
                "timestamp_jitter_bound_ms": {
                  "$rational": [
                    "0",
                    "1"
                  ]
                },
                "transport": "USB3-Vision",
                "typical_timestamp_jitter_ms": {
                  "$rational": [
                    "1",
                    "20"
                  ]
                }
              },
              "epistemic_kind": "hypothetical_assumption",
              "field_origins": {
                "/data/available": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-SYN-035",
                    "capture_sha256": "4f787c79da4931971fcf80894d53e015134dff2ac7903e292d3255608d779078",
                    "conditions": {
                      "scenario": "fictional; no real measurement or guarantee"
                    },
                    "entry_id": "LEDGER-CAP-SYN-035",
                    "evidence_class": "synthetic_declared",
                    "lexical_value": "true",
                    "locator": "/camera_supplements/CAM-FLIR/available",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": true,
                    "origin": "synthetic",
                    "source_document_sha256": "9437f7856dbd620d3315337f85abc81ef4e43c47f3a1147a5d5efc4a9f295a3b",
                    "source_id": "SYN-integration_characterization",
                    "units": "not_applicable",
                    "url": null
                  }
                ],
                "/data/bytes_per_pixel": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-SYN-042",
                    "capture_sha256": "6879dbaa5d9c48c4f663a9eca084e86129db0f236341d5713cd33741399308af",
                    "conditions": {
                      "scenario": "fictional; no real measurement or guarantee"
                    },
                    "entry_id": "LEDGER-CAP-SYN-042",
                    "evidence_class": "synthetic_declared",
                    "lexical_value": "1",
                    "locator": "/bytes_per_pixel",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": 1,
                    "origin": "synthetic",
                    "source_document_sha256": "313ab2d6f1132af45c09ecaedb4ac3c49012790c3ff42e6a0c05bf485f7ecc4c",
                    "source_id": "SYN-system_requirements",
                    "units": "bytes/px",
                    "url": null
                  }
                ],
                "/data/image_height_px": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-PUB-FLIR-SPEC-02",
                    "capture_sha256": "da94f543aa13b5486baa6d1242772b386ab2dfde67f3507c81c2eee01322d943",
                    "conditions": {
                      "mode": {
                        "pixel_format": "Mono8",
                        "power_path": "USB",
                        "resolution_context": "full"
                      },
                      "source_wording_qualification": "BFS-U3-51S5M"
                    },
                    "entry_id": "LEDGER-CAP-PUB-FLIR-SPEC-02",
                    "evidence_class": "specification",
                    "lexical_value": "2048",
                    "locator": "General Specifications > Resolution",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": 2048,
                    "origin": "public_manufacturer_capture",
                    "source_document_sha256": "9bc609a01c3811d450386662c289851cb1cd96e1c4b40d2f321361dcbb4c4af9",
                    "source_id": "PUB-FLIR-SPEC",
                    "units": "px",
                    "url": "https://softwareservices.flir.com/BFS-U3-51S5/latest/Model/spec.html"
                  }
                ],
                "/data/image_width_px": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-PUB-FLIR-SPEC-01",
                    "capture_sha256": "e142d694b75795fc34fb2516bb3cd9981cbc536b32eda0bb7e5e5fff3928791f",
                    "conditions": {
                      "mode": {
                        "pixel_format": "Mono8",
                        "power_path": "USB",
                        "resolution_context": "full"
                      },
                      "source_wording_qualification": "BFS-U3-51S5M"
                    },
                    "entry_id": "LEDGER-CAP-PUB-FLIR-SPEC-01",
                    "evidence_class": "specification",
                    "lexical_value": "2448",
                    "locator": "General Specifications > Resolution",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": 2448,
                    "origin": "public_manufacturer_capture",
                    "source_document_sha256": "9bc609a01c3811d450386662c289851cb1cd96e1c4b40d2f321361dcbb4c4af9",
                    "source_id": "PUB-FLIR-SPEC",
                    "units": "px",
                    "url": "https://softwareservices.flir.com/BFS-U3-51S5/latest/Model/spec.html"
                  }
                ],
                "/data/max_fps": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-PUB-FLIR-SPEC-03",
                    "capture_sha256": "2a54ac85be6c39915ae5a3fcd2cd9f8d07f08dd20949bf84b30b8a68e09364f2",
                    "conditions": {
                      "mode": {
                        "adc_bits": 10,
                        "binning": 1,
                        "decimation": 1,
                        "firmware": "1801.0.1.0",
                        "isp_enabled": false,
                        "pixel_format": "Mono8",
                        "power_path": "USB",
                        "resolution_context": "full"
                      },
                      "source_wording_qualification": "Specific Frame Rates, full-resolution Mono8: ISP off, ADC 10-bit, unbinned, no decimation; model firmware 1801.0.1.0."
                    },
                    "entry_id": "LEDGER-CAP-PUB-FLIR-SPEC-03",
                    "evidence_class": "specification",
                    "lexical_value": "73",
                    "locator": "General Specifications > Frame Rate",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": 73,
                    "origin": "public_manufacturer_capture",
                    "source_document_sha256": "9bc609a01c3811d450386662c289851cb1cd96e1c4b40d2f321361dcbb4c4af9",
                    "source_id": "PUB-FLIR-SPEC",
                    "units": "fps",
                    "url": "https://softwareservices.flir.com/BFS-U3-51S5/latest/Model/spec.html"
                  }
                ],
                "/data/migration_cost_points": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-SYN-036",
                    "capture_sha256": "dacb9f577630283e19bc254ed74208a0eaf758167734219dac0da8afef68d812",
                    "conditions": {
                      "scenario": "fictional; no real measurement or guarantee"
                    },
                    "entry_id": "LEDGER-CAP-SYN-036",
                    "evidence_class": "synthetic_declared",
                    "lexical_value": "2",
                    "locator": "/camera_supplements/CAM-FLIR/migration_cost_points",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": 2,
                    "origin": "synthetic",
                    "source_document_sha256": "9437f7856dbd620d3315337f85abc81ef4e43c47f3a1147a5d5efc4a9f295a3b",
                    "source_id": "SYN-integration_characterization",
                    "units": "synthetic_cost_points",
                    "url": null
                  }
                ],
                "/data/note": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-SYN-037",
                    "capture_sha256": "6cd18a8ae4655c4b6ec06107ee9698414101bd3961af25f426087b51e78fce40",
                    "conditions": {
                      "scenario": "fictional; no real measurement or guarantee"
                    },
                    "entry_id": "LEDGER-CAP-SYN-037",
                    "evidence_class": "synthetic_declared",
                    "lexical_value": "\"Missing guaranteed jitter is deliberate. Typical 0.05 ms is synthetic sample context, not a guarantee and not from FLIR.\"",
                    "locator": "/camera_supplements/CAM-FLIR/note",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": "Missing guaranteed jitter is deliberate. Typical 0.05 ms is synthetic sample context, not a guarantee and not from FLIR.",
                    "origin": "synthetic",
                    "source_document_sha256": "9437f7856dbd620d3315337f85abc81ef4e43c47f3a1147a5d5efc4a9f295a3b",
                    "source_id": "SYN-integration_characterization",
                    "units": "not_applicable",
                    "url": null
                  }
                ],
                "/data/power_W": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-PUB-FLIR-SPEC-05",
                    "capture_sha256": "eedf4ad23e2ea867663228ec9c359df739e4d1aae4a151774d56bce9301f2d6a",
                    "conditions": {
                      "mode": {
                        "power_path": "USB"
                      },
                      "source_wording_qualification": "3 W maximum"
                    },
                    "entry_id": "LEDGER-CAP-PUB-FLIR-SPEC-05",
                    "evidence_class": "maximum",
                    "lexical_value": "3",
                    "locator": "General Specifications > Power Consumption",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": 3,
                    "origin": "public_manufacturer_capture",
                    "source_document_sha256": "9bc609a01c3811d450386662c289851cb1cd96e1c4b40d2f321361dcbb4c4af9",
                    "source_id": "PUB-FLIR-SPEC",
                    "units": "W",
                    "url": "https://softwareservices.flir.com/BFS-U3-51S5/latest/Model/spec.html"
                  }
                ],
                "/data/timestamp_bias_ms_by_variant/LINE-FAST": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-SYN-038",
                    "capture_sha256": "74e61fd4be38aee9176274d4cd27ba007fd4fb8bd51bf9e0e1520adf865d0230",
                    "conditions": {
                      "scenario": "fictional; no real measurement or guarantee"
                    },
                    "entry_id": "LEDGER-CAP-SYN-038",
                    "evidence_class": "synthetic_declared",
                    "lexical_value": "0",
                    "locator": "/camera_supplements/CAM-FLIR/timestamp_bias_ms_by_variant/LINE-FAST",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": 0,
                    "origin": "synthetic",
                    "source_document_sha256": "9437f7856dbd620d3315337f85abc81ef4e43c47f3a1147a5d5efc4a9f295a3b",
                    "source_id": "SYN-integration_characterization",
                    "units": "ms",
                    "url": null
                  }
                ],
                "/data/timestamp_bias_ms_by_variant/LINE-SLOW": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-SYN-039",
                    "capture_sha256": "df8d75ee61c213e2db2415504fedef660ca0f69f653beb51c859de3ee00d8ccc",
                    "conditions": {
                      "scenario": "fictional; no real measurement or guarantee"
                    },
                    "entry_id": "LEDGER-CAP-SYN-039",
                    "evidence_class": "synthetic_declared",
                    "lexical_value": "0",
                    "locator": "/camera_supplements/CAM-FLIR/timestamp_bias_ms_by_variant/LINE-SLOW",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": 0,
                    "origin": "synthetic",
                    "source_document_sha256": "9437f7856dbd620d3315337f85abc81ef4e43c47f3a1147a5d5efc4a9f295a3b",
                    "source_id": "SYN-integration_characterization",
                    "units": "ms",
                    "url": null
                  }
                ],
                "/data/timestamp_jitter_bound_ms": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-SYN-040",
                    "capture_sha256": "96673c967cd256c6897c3bf2fe8b555625d76e5d0f0ef82c4da9ef457ecb5102",
                    "conditions": {
                      "scenario": "fictional; no real measurement or guarantee"
                    },
                    "entry_id": "LEDGER-CAP-SYN-040",
                    "evidence_class": "synthetic_guaranteed_bound",
                    "lexical_value": "null",
                    "locator": "/camera_supplements/CAM-FLIR/timestamp_jitter_bound_ms",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": null,
                    "origin": "synthetic",
                    "source_document_sha256": "9437f7856dbd620d3315337f85abc81ef4e43c47f3a1147a5d5efc4a9f295a3b",
                    "source_id": "SYN-integration_characterization",
                    "units": "ms",
                    "url": null
                  }
                ],
                "/data/transport": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-PUB-FLIR-SPEC-04",
                    "capture_sha256": "7507f207c46b136e81c3d7ad63fe17c04bd981aec8ee0c176e8bbf98f2983728",
                    "conditions": {
                      "mode": {
                        "power_path": "USB"
                      },
                      "source_wording_qualification": "USB 3.1; USB3 Vision v1.0"
                    },
                    "entry_id": "LEDGER-CAP-PUB-FLIR-SPEC-04",
                    "evidence_class": "specification",
                    "lexical_value": "\"USB3-Vision\"",
                    "locator": "General Specifications > Interface / Machine Vision Standard",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": "USB3-Vision",
                    "origin": "public_manufacturer_capture",
                    "source_document_sha256": "9bc609a01c3811d450386662c289851cb1cd96e1c4b40d2f321361dcbb4c4af9",
                    "source_id": "PUB-FLIR-SPEC",
                    "units": "not_applicable",
                    "url": "https://softwareservices.flir.com/BFS-U3-51S5/latest/Model/spec.html"
                  }
                ],
                "/data/typical_timestamp_jitter_ms": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-SYN-041",
                    "capture_sha256": "47beebb38cf1774cea9be0790f8c034db43aad66c02ff0dbfe9222857f4aa7ae",
                    "conditions": {
                      "scenario": "fictional; no real measurement or guarantee"
                    },
                    "entry_id": "LEDGER-CAP-SYN-041",
                    "evidence_class": "synthetic_declared",
                    "lexical_value": "0.05",
                    "locator": "/camera_supplements/CAM-FLIR/typical_timestamp_jitter_ms",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": {
                      "$rational": [
                        "1",
                        "20"
                      ]
                    },
                    "origin": "synthetic",
                    "source_document_sha256": "9437f7856dbd620d3315337f85abc81ef4e43c47f3a1147a5d5efc4a9f295a3b",
                    "source_id": "SYN-integration_characterization",
                    "units": "ms",
                    "url": null
                  }
                ]
              },
              "kind": "camera",
              "projection_scope": "bounded_non_voltage_synthetic",
              "revision": "hypothesis-1",
              "source_id": "GEN-CAM-FLIR--HYP-1",
              "status": "active",
              "subject_id": "CAM-FLIR",
              "supersedes": [
                "GEN-CAM-FLIR"
              ]
            },
            "virtual_path": "scenario_sources/hypothesis-01.json"
          },
          "coverage": "One representative only; not proof for the whole region",
          "decision_scope": "hypothetical_only",
          "error": null,
          "execution_status": "completed",
          "hypothetical": true,
          "input_identity": "c5e9021090d2e32e40830835d22540aca13400989837017faff6117bed4d9af3",
          "result": {
            "decision_scope": "hypothetical_only",
            "decision_status": "feasible_plan",
            "hypothetical": true,
            "selected_plan": {
              "analysis_scope": "bounded_non_voltage_synthetic",
              "camera_id": "CAM-FLIR",
              "cost_points": 2,
              "deployment_qualified": false,
              "firmware_revision": "FW-SYN-1.0",
              "full_camera_compatibility": false,
              "hypothetical": true,
              "offset_ms_by_variant": {
                "LINE-FAST": 0,
                "LINE-SLOW": 0
              },
              "optimality": "minimum_among_established_feasible_plans",
              "policy": "shared",
              "requires_human_approval": true,
              "spec_source_id": "GEN-CAM-FLIR--HYP-1",
              "unresolved_cheaper_candidates": [],
              "voltage_compatibility": "unknown_excluded"
            },
            "serialized_plan_checks": [
              {
                "limit_mm": 1,
                "serialized_offset_ms": 0,
                "variant_id": "LINE-FAST",
                "within_output_tolerance": true,
                "worst_case_error_mm": 0.2
              },
              {
                "limit_mm": 0.5,
                "serialized_offset_ms": 0,
                "variant_id": "LINE-SLOW",
                "within_output_tolerance": true,
                "worst_case_error_mm": 0.05
              }
            ]
          },
          "target_selected_and_serialized": true
        },
        "representative_ms": {
          "$rational": [
            "0",
            "1"
          ]
        },
        "target_cost_points": 2,
        "upper_inclusive": true,
        "upper_ms": {
          "$rational": [
            "0",
            "1"
          ]
        }
      },
      {
        "best_target_policy": "shared",
        "decision_scope": "conditional_mathematics_only",
        "effect": "create_first_feasible_plan",
        "feasible_target_policies": [
          "shared",
          "per_variant"
        ],
        "lower_inclusive": false,
        "lower_ms": {
          "$rational": [
            "0",
            "1"
          ]
        },
        "preview": {
          "assumed_guaranteed_jitter_ms": {
            "$rational": [
              "1",
              "5"
            ]
          },
          "assumption": {
            "base_source_id": "GEN-CAM-FLIR",
            "evidence_kind": "hypothetical_assumption",
            "field": "/data/timestamp_jitter_bound_ms",
            "hypothetical_value_ms": {
              "$rational": [
                "1",
                "5"
              ]
            },
            "promoted_to_fact": false,
            "source_id": "GEN-CAM-FLIR--HYP-1",
            "source_record": {
              "data": {
                "available": true,
                "bytes_per_pixel": 1,
                "image_height_px": 2048,
                "image_width_px": 2448,
                "max_fps": 73,
                "migration_cost_points": 2,
                "note": "Missing guaranteed jitter is deliberate. Typical 0.05 ms is synthetic sample context, not a guarantee and not from FLIR.",
                "power_W": 3,
                "supply_range_V": null,
                "timestamp_bias_ms_by_variant": {
                  "LINE-FAST": 0,
                  "LINE-SLOW": 0
                },
                "timestamp_jitter_bound_ms": {
                  "$rational": [
                    "1",
                    "5"
                  ]
                },
                "transport": "USB3-Vision",
                "typical_timestamp_jitter_ms": {
                  "$rational": [
                    "1",
                    "20"
                  ]
                }
              },
              "epistemic_kind": "hypothetical_assumption",
              "field_origins": {
                "/data/available": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-SYN-035",
                    "capture_sha256": "4f787c79da4931971fcf80894d53e015134dff2ac7903e292d3255608d779078",
                    "conditions": {
                      "scenario": "fictional; no real measurement or guarantee"
                    },
                    "entry_id": "LEDGER-CAP-SYN-035",
                    "evidence_class": "synthetic_declared",
                    "lexical_value": "true",
                    "locator": "/camera_supplements/CAM-FLIR/available",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": true,
                    "origin": "synthetic",
                    "source_document_sha256": "9437f7856dbd620d3315337f85abc81ef4e43c47f3a1147a5d5efc4a9f295a3b",
                    "source_id": "SYN-integration_characterization",
                    "units": "not_applicable",
                    "url": null
                  }
                ],
                "/data/bytes_per_pixel": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-SYN-042",
                    "capture_sha256": "6879dbaa5d9c48c4f663a9eca084e86129db0f236341d5713cd33741399308af",
                    "conditions": {
                      "scenario": "fictional; no real measurement or guarantee"
                    },
                    "entry_id": "LEDGER-CAP-SYN-042",
                    "evidence_class": "synthetic_declared",
                    "lexical_value": "1",
                    "locator": "/bytes_per_pixel",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": 1,
                    "origin": "synthetic",
                    "source_document_sha256": "313ab2d6f1132af45c09ecaedb4ac3c49012790c3ff42e6a0c05bf485f7ecc4c",
                    "source_id": "SYN-system_requirements",
                    "units": "bytes/px",
                    "url": null
                  }
                ],
                "/data/image_height_px": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-PUB-FLIR-SPEC-02",
                    "capture_sha256": "da94f543aa13b5486baa6d1242772b386ab2dfde67f3507c81c2eee01322d943",
                    "conditions": {
                      "mode": {
                        "pixel_format": "Mono8",
                        "power_path": "USB",
                        "resolution_context": "full"
                      },
                      "source_wording_qualification": "BFS-U3-51S5M"
                    },
                    "entry_id": "LEDGER-CAP-PUB-FLIR-SPEC-02",
                    "evidence_class": "specification",
                    "lexical_value": "2048",
                    "locator": "General Specifications > Resolution",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": 2048,
                    "origin": "public_manufacturer_capture",
                    "source_document_sha256": "9bc609a01c3811d450386662c289851cb1cd96e1c4b40d2f321361dcbb4c4af9",
                    "source_id": "PUB-FLIR-SPEC",
                    "units": "px",
                    "url": "https://softwareservices.flir.com/BFS-U3-51S5/latest/Model/spec.html"
                  }
                ],
                "/data/image_width_px": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-PUB-FLIR-SPEC-01",
                    "capture_sha256": "e142d694b75795fc34fb2516bb3cd9981cbc536b32eda0bb7e5e5fff3928791f",
                    "conditions": {
                      "mode": {
                        "pixel_format": "Mono8",
                        "power_path": "USB",
                        "resolution_context": "full"
                      },
                      "source_wording_qualification": "BFS-U3-51S5M"
                    },
                    "entry_id": "LEDGER-CAP-PUB-FLIR-SPEC-01",
                    "evidence_class": "specification",
                    "lexical_value": "2448",
                    "locator": "General Specifications > Resolution",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": 2448,
                    "origin": "public_manufacturer_capture",
                    "source_document_sha256": "9bc609a01c3811d450386662c289851cb1cd96e1c4b40d2f321361dcbb4c4af9",
                    "source_id": "PUB-FLIR-SPEC",
                    "units": "px",
                    "url": "https://softwareservices.flir.com/BFS-U3-51S5/latest/Model/spec.html"
                  }
                ],
                "/data/max_fps": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-PUB-FLIR-SPEC-03",
                    "capture_sha256": "2a54ac85be6c39915ae5a3fcd2cd9f8d07f08dd20949bf84b30b8a68e09364f2",
                    "conditions": {
                      "mode": {
                        "adc_bits": 10,
                        "binning": 1,
                        "decimation": 1,
                        "firmware": "1801.0.1.0",
                        "isp_enabled": false,
                        "pixel_format": "Mono8",
                        "power_path": "USB",
                        "resolution_context": "full"
                      },
                      "source_wording_qualification": "Specific Frame Rates, full-resolution Mono8: ISP off, ADC 10-bit, unbinned, no decimation; model firmware 1801.0.1.0."
                    },
                    "entry_id": "LEDGER-CAP-PUB-FLIR-SPEC-03",
                    "evidence_class": "specification",
                    "lexical_value": "73",
                    "locator": "General Specifications > Frame Rate",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": 73,
                    "origin": "public_manufacturer_capture",
                    "source_document_sha256": "9bc609a01c3811d450386662c289851cb1cd96e1c4b40d2f321361dcbb4c4af9",
                    "source_id": "PUB-FLIR-SPEC",
                    "units": "fps",
                    "url": "https://softwareservices.flir.com/BFS-U3-51S5/latest/Model/spec.html"
                  }
                ],
                "/data/migration_cost_points": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-SYN-036",
                    "capture_sha256": "dacb9f577630283e19bc254ed74208a0eaf758167734219dac0da8afef68d812",
                    "conditions": {
                      "scenario": "fictional; no real measurement or guarantee"
                    },
                    "entry_id": "LEDGER-CAP-SYN-036",
                    "evidence_class": "synthetic_declared",
                    "lexical_value": "2",
                    "locator": "/camera_supplements/CAM-FLIR/migration_cost_points",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": 2,
                    "origin": "synthetic",
                    "source_document_sha256": "9437f7856dbd620d3315337f85abc81ef4e43c47f3a1147a5d5efc4a9f295a3b",
                    "source_id": "SYN-integration_characterization",
                    "units": "synthetic_cost_points",
                    "url": null
                  }
                ],
                "/data/note": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-SYN-037",
                    "capture_sha256": "6cd18a8ae4655c4b6ec06107ee9698414101bd3961af25f426087b51e78fce40",
                    "conditions": {
                      "scenario": "fictional; no real measurement or guarantee"
                    },
                    "entry_id": "LEDGER-CAP-SYN-037",
                    "evidence_class": "synthetic_declared",
                    "lexical_value": "\"Missing guaranteed jitter is deliberate. Typical 0.05 ms is synthetic sample context, not a guarantee and not from FLIR.\"",
                    "locator": "/camera_supplements/CAM-FLIR/note",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": "Missing guaranteed jitter is deliberate. Typical 0.05 ms is synthetic sample context, not a guarantee and not from FLIR.",
                    "origin": "synthetic",
                    "source_document_sha256": "9437f7856dbd620d3315337f85abc81ef4e43c47f3a1147a5d5efc4a9f295a3b",
                    "source_id": "SYN-integration_characterization",
                    "units": "not_applicable",
                    "url": null
                  }
                ],
                "/data/power_W": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-PUB-FLIR-SPEC-05",
                    "capture_sha256": "eedf4ad23e2ea867663228ec9c359df739e4d1aae4a151774d56bce9301f2d6a",
                    "conditions": {
                      "mode": {
                        "power_path": "USB"
                      },
                      "source_wording_qualification": "3 W maximum"
                    },
                    "entry_id": "LEDGER-CAP-PUB-FLIR-SPEC-05",
                    "evidence_class": "maximum",
                    "lexical_value": "3",
                    "locator": "General Specifications > Power Consumption",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": 3,
                    "origin": "public_manufacturer_capture",
                    "source_document_sha256": "9bc609a01c3811d450386662c289851cb1cd96e1c4b40d2f321361dcbb4c4af9",
                    "source_id": "PUB-FLIR-SPEC",
                    "units": "W",
                    "url": "https://softwareservices.flir.com/BFS-U3-51S5/latest/Model/spec.html"
                  }
                ],
                "/data/timestamp_bias_ms_by_variant/LINE-FAST": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-SYN-038",
                    "capture_sha256": "74e61fd4be38aee9176274d4cd27ba007fd4fb8bd51bf9e0e1520adf865d0230",
                    "conditions": {
                      "scenario": "fictional; no real measurement or guarantee"
                    },
                    "entry_id": "LEDGER-CAP-SYN-038",
                    "evidence_class": "synthetic_declared",
                    "lexical_value": "0",
                    "locator": "/camera_supplements/CAM-FLIR/timestamp_bias_ms_by_variant/LINE-FAST",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": 0,
                    "origin": "synthetic",
                    "source_document_sha256": "9437f7856dbd620d3315337f85abc81ef4e43c47f3a1147a5d5efc4a9f295a3b",
                    "source_id": "SYN-integration_characterization",
                    "units": "ms",
                    "url": null
                  }
                ],
                "/data/timestamp_bias_ms_by_variant/LINE-SLOW": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-SYN-039",
                    "capture_sha256": "df8d75ee61c213e2db2415504fedef660ca0f69f653beb51c859de3ee00d8ccc",
                    "conditions": {
                      "scenario": "fictional; no real measurement or guarantee"
                    },
                    "entry_id": "LEDGER-CAP-SYN-039",
                    "evidence_class": "synthetic_declared",
                    "lexical_value": "0",
                    "locator": "/camera_supplements/CAM-FLIR/timestamp_bias_ms_by_variant/LINE-SLOW",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": 0,
                    "origin": "synthetic",
                    "source_document_sha256": "9437f7856dbd620d3315337f85abc81ef4e43c47f3a1147a5d5efc4a9f295a3b",
                    "source_id": "SYN-integration_characterization",
                    "units": "ms",
                    "url": null
                  }
                ],
                "/data/timestamp_jitter_bound_ms": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-SYN-040",
                    "capture_sha256": "96673c967cd256c6897c3bf2fe8b555625d76e5d0f0ef82c4da9ef457ecb5102",
                    "conditions": {
                      "scenario": "fictional; no real measurement or guarantee"
                    },
                    "entry_id": "LEDGER-CAP-SYN-040",
                    "evidence_class": "synthetic_guaranteed_bound",
                    "lexical_value": "null",
                    "locator": "/camera_supplements/CAM-FLIR/timestamp_jitter_bound_ms",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": null,
                    "origin": "synthetic",
                    "source_document_sha256": "9437f7856dbd620d3315337f85abc81ef4e43c47f3a1147a5d5efc4a9f295a3b",
                    "source_id": "SYN-integration_characterization",
                    "units": "ms",
                    "url": null
                  }
                ],
                "/data/transport": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-PUB-FLIR-SPEC-04",
                    "capture_sha256": "7507f207c46b136e81c3d7ad63fe17c04bd981aec8ee0c176e8bbf98f2983728",
                    "conditions": {
                      "mode": {
                        "power_path": "USB"
                      },
                      "source_wording_qualification": "USB 3.1; USB3 Vision v1.0"
                    },
                    "entry_id": "LEDGER-CAP-PUB-FLIR-SPEC-04",
                    "evidence_class": "specification",
                    "lexical_value": "\"USB3-Vision\"",
                    "locator": "General Specifications > Interface / Machine Vision Standard",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": "USB3-Vision",
                    "origin": "public_manufacturer_capture",
                    "source_document_sha256": "9bc609a01c3811d450386662c289851cb1cd96e1c4b40d2f321361dcbb4c4af9",
                    "source_id": "PUB-FLIR-SPEC",
                    "units": "not_applicable",
                    "url": "https://softwareservices.flir.com/BFS-U3-51S5/latest/Model/spec.html"
                  }
                ],
                "/data/typical_timestamp_jitter_ms": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-SYN-041",
                    "capture_sha256": "47beebb38cf1774cea9be0790f8c034db43aad66c02ff0dbfe9222857f4aa7ae",
                    "conditions": {
                      "scenario": "fictional; no real measurement or guarantee"
                    },
                    "entry_id": "LEDGER-CAP-SYN-041",
                    "evidence_class": "synthetic_declared",
                    "lexical_value": "0.05",
                    "locator": "/camera_supplements/CAM-FLIR/typical_timestamp_jitter_ms",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": {
                      "$rational": [
                        "1",
                        "20"
                      ]
                    },
                    "origin": "synthetic",
                    "source_document_sha256": "9437f7856dbd620d3315337f85abc81ef4e43c47f3a1147a5d5efc4a9f295a3b",
                    "source_id": "SYN-integration_characterization",
                    "units": "ms",
                    "url": null
                  }
                ]
              },
              "kind": "camera",
              "projection_scope": "bounded_non_voltage_synthetic",
              "revision": "hypothesis-1",
              "source_id": "GEN-CAM-FLIR--HYP-1",
              "status": "active",
              "subject_id": "CAM-FLIR",
              "supersedes": [
                "GEN-CAM-FLIR"
              ]
            },
            "virtual_path": "scenario_sources/hypothesis-01.json"
          },
          "coverage": "One representative only; not proof for the whole region",
          "decision_scope": "hypothetical_only",
          "error": null,
          "execution_status": "completed",
          "hypothetical": true,
          "input_identity": "05446b47feb631eb5a67c9110ebd6bdc518b151ed6fc0598e0e2e1a0aa808a20",
          "result": {
            "decision_scope": "hypothetical_only",
            "decision_status": "feasible_plan",
            "hypothetical": true,
            "selected_plan": {
              "analysis_scope": "bounded_non_voltage_synthetic",
              "camera_id": "CAM-FLIR",
              "cost_points": 2,
              "deployment_qualified": false,
              "firmware_revision": "FW-SYN-1.0",
              "full_camera_compatibility": false,
              "hypothetical": true,
              "offset_ms_by_variant": {
                "LINE-FAST": 0,
                "LINE-SLOW": 0
              },
              "optimality": "minimum_among_established_feasible_plans",
              "policy": "shared",
              "requires_human_approval": true,
              "spec_source_id": "GEN-CAM-FLIR--HYP-1",
              "unresolved_cheaper_candidates": [],
              "voltage_compatibility": "unknown_excluded"
            },
            "serialized_plan_checks": [
              {
                "limit_mm": 1,
                "serialized_offset_ms": 0,
                "variant_id": "LINE-FAST",
                "within_output_tolerance": true,
                "worst_case_error_mm": 0.6
              },
              {
                "limit_mm": 0.5,
                "serialized_offset_ms": 0,
                "variant_id": "LINE-SLOW",
                "within_output_tolerance": true,
                "worst_case_error_mm": 0.15
              }
            ]
          },
          "target_selected_and_serialized": true
        },
        "representative_ms": {
          "$rational": [
            "1",
            "5"
          ]
        },
        "target_cost_points": 2,
        "upper_inclusive": false,
        "upper_ms": {
          "$rational": [
            "2",
            "5"
          ]
        }
      },
      {
        "best_target_policy": "shared",
        "decision_scope": "conditional_mathematics_only",
        "effect": "create_first_feasible_plan",
        "feasible_target_policies": [
          "shared",
          "per_variant"
        ],
        "lower_inclusive": true,
        "lower_ms": {
          "$rational": [
            "2",
            "5"
          ]
        },
        "preview": {
          "assumed_guaranteed_jitter_ms": {
            "$rational": [
              "2",
              "5"
            ]
          },
          "assumption": {
            "base_source_id": "GEN-CAM-FLIR",
            "evidence_kind": "hypothetical_assumption",
            "field": "/data/timestamp_jitter_bound_ms",
            "hypothetical_value_ms": {
              "$rational": [
                "2",
                "5"
              ]
            },
            "promoted_to_fact": false,
            "source_id": "GEN-CAM-FLIR--HYP-1",
            "source_record": {
              "data": {
                "available": true,
                "bytes_per_pixel": 1,
                "image_height_px": 2048,
                "image_width_px": 2448,
                "max_fps": 73,
                "migration_cost_points": 2,
                "note": "Missing guaranteed jitter is deliberate. Typical 0.05 ms is synthetic sample context, not a guarantee and not from FLIR.",
                "power_W": 3,
                "supply_range_V": null,
                "timestamp_bias_ms_by_variant": {
                  "LINE-FAST": 0,
                  "LINE-SLOW": 0
                },
                "timestamp_jitter_bound_ms": {
                  "$rational": [
                    "2",
                    "5"
                  ]
                },
                "transport": "USB3-Vision",
                "typical_timestamp_jitter_ms": {
                  "$rational": [
                    "1",
                    "20"
                  ]
                }
              },
              "epistemic_kind": "hypothetical_assumption",
              "field_origins": {
                "/data/available": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-SYN-035",
                    "capture_sha256": "4f787c79da4931971fcf80894d53e015134dff2ac7903e292d3255608d779078",
                    "conditions": {
                      "scenario": "fictional; no real measurement or guarantee"
                    },
                    "entry_id": "LEDGER-CAP-SYN-035",
                    "evidence_class": "synthetic_declared",
                    "lexical_value": "true",
                    "locator": "/camera_supplements/CAM-FLIR/available",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": true,
                    "origin": "synthetic",
                    "source_document_sha256": "9437f7856dbd620d3315337f85abc81ef4e43c47f3a1147a5d5efc4a9f295a3b",
                    "source_id": "SYN-integration_characterization",
                    "units": "not_applicable",
                    "url": null
                  }
                ],
                "/data/bytes_per_pixel": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-SYN-042",
                    "capture_sha256": "6879dbaa5d9c48c4f663a9eca084e86129db0f236341d5713cd33741399308af",
                    "conditions": {
                      "scenario": "fictional; no real measurement or guarantee"
                    },
                    "entry_id": "LEDGER-CAP-SYN-042",
                    "evidence_class": "synthetic_declared",
                    "lexical_value": "1",
                    "locator": "/bytes_per_pixel",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": 1,
                    "origin": "synthetic",
                    "source_document_sha256": "313ab2d6f1132af45c09ecaedb4ac3c49012790c3ff42e6a0c05bf485f7ecc4c",
                    "source_id": "SYN-system_requirements",
                    "units": "bytes/px",
                    "url": null
                  }
                ],
                "/data/image_height_px": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-PUB-FLIR-SPEC-02",
                    "capture_sha256": "da94f543aa13b5486baa6d1242772b386ab2dfde67f3507c81c2eee01322d943",
                    "conditions": {
                      "mode": {
                        "pixel_format": "Mono8",
                        "power_path": "USB",
                        "resolution_context": "full"
                      },
                      "source_wording_qualification": "BFS-U3-51S5M"
                    },
                    "entry_id": "LEDGER-CAP-PUB-FLIR-SPEC-02",
                    "evidence_class": "specification",
                    "lexical_value": "2048",
                    "locator": "General Specifications > Resolution",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": 2048,
                    "origin": "public_manufacturer_capture",
                    "source_document_sha256": "9bc609a01c3811d450386662c289851cb1cd96e1c4b40d2f321361dcbb4c4af9",
                    "source_id": "PUB-FLIR-SPEC",
                    "units": "px",
                    "url": "https://softwareservices.flir.com/BFS-U3-51S5/latest/Model/spec.html"
                  }
                ],
                "/data/image_width_px": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-PUB-FLIR-SPEC-01",
                    "capture_sha256": "e142d694b75795fc34fb2516bb3cd9981cbc536b32eda0bb7e5e5fff3928791f",
                    "conditions": {
                      "mode": {
                        "pixel_format": "Mono8",
                        "power_path": "USB",
                        "resolution_context": "full"
                      },
                      "source_wording_qualification": "BFS-U3-51S5M"
                    },
                    "entry_id": "LEDGER-CAP-PUB-FLIR-SPEC-01",
                    "evidence_class": "specification",
                    "lexical_value": "2448",
                    "locator": "General Specifications > Resolution",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": 2448,
                    "origin": "public_manufacturer_capture",
                    "source_document_sha256": "9bc609a01c3811d450386662c289851cb1cd96e1c4b40d2f321361dcbb4c4af9",
                    "source_id": "PUB-FLIR-SPEC",
                    "units": "px",
                    "url": "https://softwareservices.flir.com/BFS-U3-51S5/latest/Model/spec.html"
                  }
                ],
                "/data/max_fps": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-PUB-FLIR-SPEC-03",
                    "capture_sha256": "2a54ac85be6c39915ae5a3fcd2cd9f8d07f08dd20949bf84b30b8a68e09364f2",
                    "conditions": {
                      "mode": {
                        "adc_bits": 10,
                        "binning": 1,
                        "decimation": 1,
                        "firmware": "1801.0.1.0",
                        "isp_enabled": false,
                        "pixel_format": "Mono8",
                        "power_path": "USB",
                        "resolution_context": "full"
                      },
                      "source_wording_qualification": "Specific Frame Rates, full-resolution Mono8: ISP off, ADC 10-bit, unbinned, no decimation; model firmware 1801.0.1.0."
                    },
                    "entry_id": "LEDGER-CAP-PUB-FLIR-SPEC-03",
                    "evidence_class": "specification",
                    "lexical_value": "73",
                    "locator": "General Specifications > Frame Rate",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": 73,
                    "origin": "public_manufacturer_capture",
                    "source_document_sha256": "9bc609a01c3811d450386662c289851cb1cd96e1c4b40d2f321361dcbb4c4af9",
                    "source_id": "PUB-FLIR-SPEC",
                    "units": "fps",
                    "url": "https://softwareservices.flir.com/BFS-U3-51S5/latest/Model/spec.html"
                  }
                ],
                "/data/migration_cost_points": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-SYN-036",
                    "capture_sha256": "dacb9f577630283e19bc254ed74208a0eaf758167734219dac0da8afef68d812",
                    "conditions": {
                      "scenario": "fictional; no real measurement or guarantee"
                    },
                    "entry_id": "LEDGER-CAP-SYN-036",
                    "evidence_class": "synthetic_declared",
                    "lexical_value": "2",
                    "locator": "/camera_supplements/CAM-FLIR/migration_cost_points",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": 2,
                    "origin": "synthetic",
                    "source_document_sha256": "9437f7856dbd620d3315337f85abc81ef4e43c47f3a1147a5d5efc4a9f295a3b",
                    "source_id": "SYN-integration_characterization",
                    "units": "synthetic_cost_points",
                    "url": null
                  }
                ],
                "/data/note": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-SYN-037",
                    "capture_sha256": "6cd18a8ae4655c4b6ec06107ee9698414101bd3961af25f426087b51e78fce40",
                    "conditions": {
                      "scenario": "fictional; no real measurement or guarantee"
                    },
                    "entry_id": "LEDGER-CAP-SYN-037",
                    "evidence_class": "synthetic_declared",
                    "lexical_value": "\"Missing guaranteed jitter is deliberate. Typical 0.05 ms is synthetic sample context, not a guarantee and not from FLIR.\"",
                    "locator": "/camera_supplements/CAM-FLIR/note",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": "Missing guaranteed jitter is deliberate. Typical 0.05 ms is synthetic sample context, not a guarantee and not from FLIR.",
                    "origin": "synthetic",
                    "source_document_sha256": "9437f7856dbd620d3315337f85abc81ef4e43c47f3a1147a5d5efc4a9f295a3b",
                    "source_id": "SYN-integration_characterization",
                    "units": "not_applicable",
                    "url": null
                  }
                ],
                "/data/power_W": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-PUB-FLIR-SPEC-05",
                    "capture_sha256": "eedf4ad23e2ea867663228ec9c359df739e4d1aae4a151774d56bce9301f2d6a",
                    "conditions": {
                      "mode": {
                        "power_path": "USB"
                      },
                      "source_wording_qualification": "3 W maximum"
                    },
                    "entry_id": "LEDGER-CAP-PUB-FLIR-SPEC-05",
                    "evidence_class": "maximum",
                    "lexical_value": "3",
                    "locator": "General Specifications > Power Consumption",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": 3,
                    "origin": "public_manufacturer_capture",
                    "source_document_sha256": "9bc609a01c3811d450386662c289851cb1cd96e1c4b40d2f321361dcbb4c4af9",
                    "source_id": "PUB-FLIR-SPEC",
                    "units": "W",
                    "url": "https://softwareservices.flir.com/BFS-U3-51S5/latest/Model/spec.html"
                  }
                ],
                "/data/timestamp_bias_ms_by_variant/LINE-FAST": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-SYN-038",
                    "capture_sha256": "74e61fd4be38aee9176274d4cd27ba007fd4fb8bd51bf9e0e1520adf865d0230",
                    "conditions": {
                      "scenario": "fictional; no real measurement or guarantee"
                    },
                    "entry_id": "LEDGER-CAP-SYN-038",
                    "evidence_class": "synthetic_declared",
                    "lexical_value": "0",
                    "locator": "/camera_supplements/CAM-FLIR/timestamp_bias_ms_by_variant/LINE-FAST",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": 0,
                    "origin": "synthetic",
                    "source_document_sha256": "9437f7856dbd620d3315337f85abc81ef4e43c47f3a1147a5d5efc4a9f295a3b",
                    "source_id": "SYN-integration_characterization",
                    "units": "ms",
                    "url": null
                  }
                ],
                "/data/timestamp_bias_ms_by_variant/LINE-SLOW": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-SYN-039",
                    "capture_sha256": "df8d75ee61c213e2db2415504fedef660ca0f69f653beb51c859de3ee00d8ccc",
                    "conditions": {
                      "scenario": "fictional; no real measurement or guarantee"
                    },
                    "entry_id": "LEDGER-CAP-SYN-039",
                    "evidence_class": "synthetic_declared",
                    "lexical_value": "0",
                    "locator": "/camera_supplements/CAM-FLIR/timestamp_bias_ms_by_variant/LINE-SLOW",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": 0,
                    "origin": "synthetic",
                    "source_document_sha256": "9437f7856dbd620d3315337f85abc81ef4e43c47f3a1147a5d5efc4a9f295a3b",
                    "source_id": "SYN-integration_characterization",
                    "units": "ms",
                    "url": null
                  }
                ],
                "/data/timestamp_jitter_bound_ms": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-SYN-040",
                    "capture_sha256": "96673c967cd256c6897c3bf2fe8b555625d76e5d0f0ef82c4da9ef457ecb5102",
                    "conditions": {
                      "scenario": "fictional; no real measurement or guarantee"
                    },
                    "entry_id": "LEDGER-CAP-SYN-040",
                    "evidence_class": "synthetic_guaranteed_bound",
                    "lexical_value": "null",
                    "locator": "/camera_supplements/CAM-FLIR/timestamp_jitter_bound_ms",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": null,
                    "origin": "synthetic",
                    "source_document_sha256": "9437f7856dbd620d3315337f85abc81ef4e43c47f3a1147a5d5efc4a9f295a3b",
                    "source_id": "SYN-integration_characterization",
                    "units": "ms",
                    "url": null
                  }
                ],
                "/data/transport": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-PUB-FLIR-SPEC-04",
                    "capture_sha256": "7507f207c46b136e81c3d7ad63fe17c04bd981aec8ee0c176e8bbf98f2983728",
                    "conditions": {
                      "mode": {
                        "power_path": "USB"
                      },
                      "source_wording_qualification": "USB 3.1; USB3 Vision v1.0"
                    },
                    "entry_id": "LEDGER-CAP-PUB-FLIR-SPEC-04",
                    "evidence_class": "specification",
                    "lexical_value": "\"USB3-Vision\"",
                    "locator": "General Specifications > Interface / Machine Vision Standard",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": "USB3-Vision",
                    "origin": "public_manufacturer_capture",
                    "source_document_sha256": "9bc609a01c3811d450386662c289851cb1cd96e1c4b40d2f321361dcbb4c4af9",
                    "source_id": "PUB-FLIR-SPEC",
                    "units": "not_applicable",
                    "url": "https://softwareservices.flir.com/BFS-U3-51S5/latest/Model/spec.html"
                  }
                ],
                "/data/typical_timestamp_jitter_ms": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-SYN-041",
                    "capture_sha256": "47beebb38cf1774cea9be0790f8c034db43aad66c02ff0dbfe9222857f4aa7ae",
                    "conditions": {
                      "scenario": "fictional; no real measurement or guarantee"
                    },
                    "entry_id": "LEDGER-CAP-SYN-041",
                    "evidence_class": "synthetic_declared",
                    "lexical_value": "0.05",
                    "locator": "/camera_supplements/CAM-FLIR/typical_timestamp_jitter_ms",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": {
                      "$rational": [
                        "1",
                        "20"
                      ]
                    },
                    "origin": "synthetic",
                    "source_document_sha256": "9437f7856dbd620d3315337f85abc81ef4e43c47f3a1147a5d5efc4a9f295a3b",
                    "source_id": "SYN-integration_characterization",
                    "units": "ms",
                    "url": null
                  }
                ]
              },
              "kind": "camera",
              "projection_scope": "bounded_non_voltage_synthetic",
              "revision": "hypothesis-1",
              "source_id": "GEN-CAM-FLIR--HYP-1",
              "status": "active",
              "subject_id": "CAM-FLIR",
              "supersedes": [
                "GEN-CAM-FLIR"
              ]
            },
            "virtual_path": "scenario_sources/hypothesis-01.json"
          },
          "coverage": "One representative only; not proof for the whole region",
          "decision_scope": "hypothetical_only",
          "error": null,
          "execution_status": "completed",
          "hypothetical": true,
          "input_identity": "69af07c573aeb9bfebc9cf637bda529e87e0c00e9f0a07b655fded1d94c8176d",
          "result": {
            "decision_scope": "hypothetical_only",
            "decision_status": "feasible_plan",
            "hypothetical": true,
            "selected_plan": {
              "analysis_scope": "bounded_non_voltage_synthetic",
              "camera_id": "CAM-FLIR",
              "cost_points": 2,
              "deployment_qualified": false,
              "firmware_revision": "FW-SYN-1.0",
              "full_camera_compatibility": false,
              "hypothetical": true,
              "offset_ms_by_variant": {
                "LINE-FAST": 0,
                "LINE-SLOW": 0
              },
              "optimality": "minimum_among_established_feasible_plans",
              "policy": "shared",
              "requires_human_approval": true,
              "spec_source_id": "GEN-CAM-FLIR--HYP-1",
              "unresolved_cheaper_candidates": [],
              "voltage_compatibility": "unknown_excluded"
            },
            "serialized_plan_checks": [
              {
                "limit_mm": 1,
                "serialized_offset_ms": 0,
                "variant_id": "LINE-FAST",
                "within_output_tolerance": true,
                "worst_case_error_mm": 1
              },
              {
                "limit_mm": 0.5,
                "serialized_offset_ms": 0,
                "variant_id": "LINE-SLOW",
                "within_output_tolerance": true,
                "worst_case_error_mm": 0.25
              }
            ]
          },
          "target_selected_and_serialized": true
        },
        "representative_ms": {
          "$rational": [
            "2",
            "5"
          ]
        },
        "target_cost_points": 2,
        "upper_inclusive": true,
        "upper_ms": {
          "$rational": [
            "2",
            "5"
          ]
        }
      },
      {
        "best_target_policy": null,
        "decision_scope": "conditional_mathematics_only",
        "effect": "no_target_plan",
        "feasible_target_policies": [],
        "lower_inclusive": false,
        "lower_ms": {
          "$rational": [
            "2",
            "5"
          ]
        },
        "preview": {
          "assumed_guaranteed_jitter_ms": {
            "$rational": [
              "7",
              "5"
            ]
          },
          "assumption": {
            "base_source_id": "GEN-CAM-FLIR",
            "evidence_kind": "hypothetical_assumption",
            "field": "/data/timestamp_jitter_bound_ms",
            "hypothetical_value_ms": {
              "$rational": [
                "7",
                "5"
              ]
            },
            "promoted_to_fact": false,
            "source_id": "GEN-CAM-FLIR--HYP-1",
            "source_record": {
              "data": {
                "available": true,
                "bytes_per_pixel": 1,
                "image_height_px": 2048,
                "image_width_px": 2448,
                "max_fps": 73,
                "migration_cost_points": 2,
                "note": "Missing guaranteed jitter is deliberate. Typical 0.05 ms is synthetic sample context, not a guarantee and not from FLIR.",
                "power_W": 3,
                "supply_range_V": null,
                "timestamp_bias_ms_by_variant": {
                  "LINE-FAST": 0,
                  "LINE-SLOW": 0
                },
                "timestamp_jitter_bound_ms": {
                  "$rational": [
                    "7",
                    "5"
                  ]
                },
                "transport": "USB3-Vision",
                "typical_timestamp_jitter_ms": {
                  "$rational": [
                    "1",
                    "20"
                  ]
                }
              },
              "epistemic_kind": "hypothetical_assumption",
              "field_origins": {
                "/data/available": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-SYN-035",
                    "capture_sha256": "4f787c79da4931971fcf80894d53e015134dff2ac7903e292d3255608d779078",
                    "conditions": {
                      "scenario": "fictional; no real measurement or guarantee"
                    },
                    "entry_id": "LEDGER-CAP-SYN-035",
                    "evidence_class": "synthetic_declared",
                    "lexical_value": "true",
                    "locator": "/camera_supplements/CAM-FLIR/available",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": true,
                    "origin": "synthetic",
                    "source_document_sha256": "9437f7856dbd620d3315337f85abc81ef4e43c47f3a1147a5d5efc4a9f295a3b",
                    "source_id": "SYN-integration_characterization",
                    "units": "not_applicable",
                    "url": null
                  }
                ],
                "/data/bytes_per_pixel": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-SYN-042",
                    "capture_sha256": "6879dbaa5d9c48c4f663a9eca084e86129db0f236341d5713cd33741399308af",
                    "conditions": {
                      "scenario": "fictional; no real measurement or guarantee"
                    },
                    "entry_id": "LEDGER-CAP-SYN-042",
                    "evidence_class": "synthetic_declared",
                    "lexical_value": "1",
                    "locator": "/bytes_per_pixel",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": 1,
                    "origin": "synthetic",
                    "source_document_sha256": "313ab2d6f1132af45c09ecaedb4ac3c49012790c3ff42e6a0c05bf485f7ecc4c",
                    "source_id": "SYN-system_requirements",
                    "units": "bytes/px",
                    "url": null
                  }
                ],
                "/data/image_height_px": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-PUB-FLIR-SPEC-02",
                    "capture_sha256": "da94f543aa13b5486baa6d1242772b386ab2dfde67f3507c81c2eee01322d943",
                    "conditions": {
                      "mode": {
                        "pixel_format": "Mono8",
                        "power_path": "USB",
                        "resolution_context": "full"
                      },
                      "source_wording_qualification": "BFS-U3-51S5M"
                    },
                    "entry_id": "LEDGER-CAP-PUB-FLIR-SPEC-02",
                    "evidence_class": "specification",
                    "lexical_value": "2048",
                    "locator": "General Specifications > Resolution",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": 2048,
                    "origin": "public_manufacturer_capture",
                    "source_document_sha256": "9bc609a01c3811d450386662c289851cb1cd96e1c4b40d2f321361dcbb4c4af9",
                    "source_id": "PUB-FLIR-SPEC",
                    "units": "px",
                    "url": "https://softwareservices.flir.com/BFS-U3-51S5/latest/Model/spec.html"
                  }
                ],
                "/data/image_width_px": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-PUB-FLIR-SPEC-01",
                    "capture_sha256": "e142d694b75795fc34fb2516bb3cd9981cbc536b32eda0bb7e5e5fff3928791f",
                    "conditions": {
                      "mode": {
                        "pixel_format": "Mono8",
                        "power_path": "USB",
                        "resolution_context": "full"
                      },
                      "source_wording_qualification": "BFS-U3-51S5M"
                    },
                    "entry_id": "LEDGER-CAP-PUB-FLIR-SPEC-01",
                    "evidence_class": "specification",
                    "lexical_value": "2448",
                    "locator": "General Specifications > Resolution",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": 2448,
                    "origin": "public_manufacturer_capture",
                    "source_document_sha256": "9bc609a01c3811d450386662c289851cb1cd96e1c4b40d2f321361dcbb4c4af9",
                    "source_id": "PUB-FLIR-SPEC",
                    "units": "px",
                    "url": "https://softwareservices.flir.com/BFS-U3-51S5/latest/Model/spec.html"
                  }
                ],
                "/data/max_fps": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-PUB-FLIR-SPEC-03",
                    "capture_sha256": "2a54ac85be6c39915ae5a3fcd2cd9f8d07f08dd20949bf84b30b8a68e09364f2",
                    "conditions": {
                      "mode": {
                        "adc_bits": 10,
                        "binning": 1,
                        "decimation": 1,
                        "firmware": "1801.0.1.0",
                        "isp_enabled": false,
                        "pixel_format": "Mono8",
                        "power_path": "USB",
                        "resolution_context": "full"
                      },
                      "source_wording_qualification": "Specific Frame Rates, full-resolution Mono8: ISP off, ADC 10-bit, unbinned, no decimation; model firmware 1801.0.1.0."
                    },
                    "entry_id": "LEDGER-CAP-PUB-FLIR-SPEC-03",
                    "evidence_class": "specification",
                    "lexical_value": "73",
                    "locator": "General Specifications > Frame Rate",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": 73,
                    "origin": "public_manufacturer_capture",
                    "source_document_sha256": "9bc609a01c3811d450386662c289851cb1cd96e1c4b40d2f321361dcbb4c4af9",
                    "source_id": "PUB-FLIR-SPEC",
                    "units": "fps",
                    "url": "https://softwareservices.flir.com/BFS-U3-51S5/latest/Model/spec.html"
                  }
                ],
                "/data/migration_cost_points": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-SYN-036",
                    "capture_sha256": "dacb9f577630283e19bc254ed74208a0eaf758167734219dac0da8afef68d812",
                    "conditions": {
                      "scenario": "fictional; no real measurement or guarantee"
                    },
                    "entry_id": "LEDGER-CAP-SYN-036",
                    "evidence_class": "synthetic_declared",
                    "lexical_value": "2",
                    "locator": "/camera_supplements/CAM-FLIR/migration_cost_points",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": 2,
                    "origin": "synthetic",
                    "source_document_sha256": "9437f7856dbd620d3315337f85abc81ef4e43c47f3a1147a5d5efc4a9f295a3b",
                    "source_id": "SYN-integration_characterization",
                    "units": "synthetic_cost_points",
                    "url": null
                  }
                ],
                "/data/note": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-SYN-037",
                    "capture_sha256": "6cd18a8ae4655c4b6ec06107ee9698414101bd3961af25f426087b51e78fce40",
                    "conditions": {
                      "scenario": "fictional; no real measurement or guarantee"
                    },
                    "entry_id": "LEDGER-CAP-SYN-037",
                    "evidence_class": "synthetic_declared",
                    "lexical_value": "\"Missing guaranteed jitter is deliberate. Typical 0.05 ms is synthetic sample context, not a guarantee and not from FLIR.\"",
                    "locator": "/camera_supplements/CAM-FLIR/note",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": "Missing guaranteed jitter is deliberate. Typical 0.05 ms is synthetic sample context, not a guarantee and not from FLIR.",
                    "origin": "synthetic",
                    "source_document_sha256": "9437f7856dbd620d3315337f85abc81ef4e43c47f3a1147a5d5efc4a9f295a3b",
                    "source_id": "SYN-integration_characterization",
                    "units": "not_applicable",
                    "url": null
                  }
                ],
                "/data/power_W": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-PUB-FLIR-SPEC-05",
                    "capture_sha256": "eedf4ad23e2ea867663228ec9c359df739e4d1aae4a151774d56bce9301f2d6a",
                    "conditions": {
                      "mode": {
                        "power_path": "USB"
                      },
                      "source_wording_qualification": "3 W maximum"
                    },
                    "entry_id": "LEDGER-CAP-PUB-FLIR-SPEC-05",
                    "evidence_class": "maximum",
                    "lexical_value": "3",
                    "locator": "General Specifications > Power Consumption",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": 3,
                    "origin": "public_manufacturer_capture",
                    "source_document_sha256": "9bc609a01c3811d450386662c289851cb1cd96e1c4b40d2f321361dcbb4c4af9",
                    "source_id": "PUB-FLIR-SPEC",
                    "units": "W",
                    "url": "https://softwareservices.flir.com/BFS-U3-51S5/latest/Model/spec.html"
                  }
                ],
                "/data/timestamp_bias_ms_by_variant/LINE-FAST": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-SYN-038",
                    "capture_sha256": "74e61fd4be38aee9176274d4cd27ba007fd4fb8bd51bf9e0e1520adf865d0230",
                    "conditions": {
                      "scenario": "fictional; no real measurement or guarantee"
                    },
                    "entry_id": "LEDGER-CAP-SYN-038",
                    "evidence_class": "synthetic_declared",
                    "lexical_value": "0",
                    "locator": "/camera_supplements/CAM-FLIR/timestamp_bias_ms_by_variant/LINE-FAST",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": 0,
                    "origin": "synthetic",
                    "source_document_sha256": "9437f7856dbd620d3315337f85abc81ef4e43c47f3a1147a5d5efc4a9f295a3b",
                    "source_id": "SYN-integration_characterization",
                    "units": "ms",
                    "url": null
                  }
                ],
                "/data/timestamp_bias_ms_by_variant/LINE-SLOW": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-SYN-039",
                    "capture_sha256": "df8d75ee61c213e2db2415504fedef660ca0f69f653beb51c859de3ee00d8ccc",
                    "conditions": {
                      "scenario": "fictional; no real measurement or guarantee"
                    },
                    "entry_id": "LEDGER-CAP-SYN-039",
                    "evidence_class": "synthetic_declared",
                    "lexical_value": "0",
                    "locator": "/camera_supplements/CAM-FLIR/timestamp_bias_ms_by_variant/LINE-SLOW",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": 0,
                    "origin": "synthetic",
                    "source_document_sha256": "9437f7856dbd620d3315337f85abc81ef4e43c47f3a1147a5d5efc4a9f295a3b",
                    "source_id": "SYN-integration_characterization",
                    "units": "ms",
                    "url": null
                  }
                ],
                "/data/timestamp_jitter_bound_ms": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-SYN-040",
                    "capture_sha256": "96673c967cd256c6897c3bf2fe8b555625d76e5d0f0ef82c4da9ef457ecb5102",
                    "conditions": {
                      "scenario": "fictional; no real measurement or guarantee"
                    },
                    "entry_id": "LEDGER-CAP-SYN-040",
                    "evidence_class": "synthetic_guaranteed_bound",
                    "lexical_value": "null",
                    "locator": "/camera_supplements/CAM-FLIR/timestamp_jitter_bound_ms",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": null,
                    "origin": "synthetic",
                    "source_document_sha256": "9437f7856dbd620d3315337f85abc81ef4e43c47f3a1147a5d5efc4a9f295a3b",
                    "source_id": "SYN-integration_characterization",
                    "units": "ms",
                    "url": null
                  }
                ],
                "/data/transport": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-PUB-FLIR-SPEC-04",
                    "capture_sha256": "7507f207c46b136e81c3d7ad63fe17c04bd981aec8ee0c176e8bbf98f2983728",
                    "conditions": {
                      "mode": {
                        "power_path": "USB"
                      },
                      "source_wording_qualification": "USB 3.1; USB3 Vision v1.0"
                    },
                    "entry_id": "LEDGER-CAP-PUB-FLIR-SPEC-04",
                    "evidence_class": "specification",
                    "lexical_value": "\"USB3-Vision\"",
                    "locator": "General Specifications > Interface / Machine Vision Standard",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": "USB3-Vision",
                    "origin": "public_manufacturer_capture",
                    "source_document_sha256": "9bc609a01c3811d450386662c289851cb1cd96e1c4b40d2f321361dcbb4c4af9",
                    "source_id": "PUB-FLIR-SPEC",
                    "units": "not_applicable",
                    "url": "https://softwareservices.flir.com/BFS-U3-51S5/latest/Model/spec.html"
                  }
                ],
                "/data/typical_timestamp_jitter_ms": [
                  {
                    "applicability": "APPLICABLE",
                    "capture_id": "CAP-SYN-041",
                    "capture_sha256": "47beebb38cf1774cea9be0790f8c034db43aad66c02ff0dbfe9222857f4aa7ae",
                    "conditions": {
                      "scenario": "fictional; no real measurement or guarantee"
                    },
                    "entry_id": "LEDGER-CAP-SYN-041",
                    "evidence_class": "synthetic_declared",
                    "lexical_value": "0.05",
                    "locator": "/camera_supplements/CAM-FLIR/typical_timestamp_jitter_ms",
                    "minimum_payload_MB_s": null,
                    "normalized_exact": {
                      "$rational": [
                        "1",
                        "20"
                      ]
                    },
                    "origin": "synthetic",
                    "source_document_sha256": "9437f7856dbd620d3315337f85abc81ef4e43c47f3a1147a5d5efc4a9f295a3b",
                    "source_id": "SYN-integration_characterization",
                    "units": "ms",
                    "url": null
                  }
                ]
              },
              "kind": "camera",
              "projection_scope": "bounded_non_voltage_synthetic",
              "revision": "hypothesis-1",
              "source_id": "GEN-CAM-FLIR--HYP-1",
              "status": "active",
              "subject_id": "CAM-FLIR",
              "supersedes": [
                "GEN-CAM-FLIR"
              ]
            },
            "virtual_path": "scenario_sources/hypothesis-01.json"
          },
          "coverage": "One representative only; not proof for the whole region",
          "decision_scope": "hypothetical_only",
          "error": null,
          "execution_status": "completed",
          "hypothetical": true,
          "input_identity": "2d3c75f991b018b2240028c7c6eef8ab478d43b35acc5ddde51747de98c39329",
          "result": {
            "decision_scope": "hypothetical_only",
            "decision_status": "insufficient_evidence",
            "hypothetical": true,
            "selected_plan": null,
            "serialized_plan_checks": []
          },
          "target_selected_and_serialized": false
        },
        "representative_ms": {
          "$rational": [
            "7",
            "5"
          ]
        },
        "target_cost_points": null,
        "upper_inclusive": false,
        "upper_ms": null
      }
    ],
    "remaining_unknowns": [],
    "rule_ids": [
      "R-AUTH",
      "R-U01",
      "R-TIME",
      "R-SELECT",
      "R-SERIAL",
      "R-EVIDENCE",
      "R-SIM"
    ],
    "run_kind": "conditional_evidence_analysis",
    "target": {
      "camera_id": "CAM-FLIR",
      "evidence_source_role": "synthetic_integration_characterization",
      "field": "timestamp_jitter_bound_ms",
      "locators": [
        {
          "file": "sources/GEN-CAM-FLIR.json",
          "locator": "/data/timestamp_jitter_bound_ms",
          "requested_locator": "/data/timestamp_jitter_bound_ms",
          "source_id": "GEN-CAM-FLIR",
          "source_identity": "5b64cf87df6b512cb4a7cb00e8e0df088848fd3ff841035b4964f0c53142dad5"
        }
      ],
      "requested_locator": "/data/timestamp_jitter_bound_ms",
      "source_id": "GEN-CAM-FLIR",
      "source_ids": [
        "GEN-CAM-FLIR"
      ],
      "spec_revision": 1,
      "upstream_origins": [
        {
          "applicability": "APPLICABLE",
          "capture_id": "CAP-SYN-040",
          "capture_sha256": "96673c967cd256c6897c3bf2fe8b555625d76e5d0f0ef82c4da9ef457ecb5102",
          "conditions": {
            "scenario": "fictional; no real measurement or guarantee"
          },
          "entry_id": "LEDGER-CAP-SYN-040",
          "evidence_class": "synthetic_guaranteed_bound",
          "lexical_value": "null",
          "locator": "/camera_supplements/CAM-FLIR/timestamp_jitter_bound_ms",
          "minimum_payload_MB_s": null,
          "normalized_exact": null,
          "origin": "synthetic",
          "source_document_sha256": "9437f7856dbd620d3315337f85abc81ef4e43c47f3a1147a5d5efc4a9f295a3b",
          "source_id": "SYN-integration_characterization",
          "units": "ms",
          "url": null
        }
      ]
    }
  },
  "run_kind": "conditional_evidence_analysis",
  "wrapper_version": "0.1.2"
}
```

## Scope

```json
"Bounded non-voltage synthetic installation; real source captures; no full camera compatibility."
```

Full decision verification checks this deterministic view under the v0.1.2 contract. Engine reproduction alone does not. Recorded file integrity is not authorship, manufacturer truth, physical identity or engineering approval. Creation IDs/timestamps and display metadata are not authenticated. Any permitted operator note is manifest-covered but not semantically verified.
