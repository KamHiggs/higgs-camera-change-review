Candidate: CAM-FLIR. Current decision: insufficient_evidence.

Analysis: blocked.

Jitter alone cannot overcome: LINE-FAST: frame_rate: established failure; LINE-SLOW: frame_rate: established failure.

LINE-FAST frame_rate: value 24 must satisfy >= 45; source locators are retained in blocker_details.

LINE-SLOW frame_rate: value 24 must satisfy >= 30; source locators are retained in blocker_details.

No jitter-only request is issued as sufficient to improve or add a tied option to this decision.

Voltage compatibility remains unknown outside this bounded subsystem. No jitter guarantee establishes full replacement suitability.

Synthetic model only; facts are supplied, not independently authenticated.

Cost comparison covers established plans only; unresolved other candidates can still matter.

Representative previews are hypothetical witnesses, not a proof of encoding over a whole region.

Mathematical conditions are not a guaranteed executable configuration. No supplier fact, deployment approval, or hardware qualification was created.
