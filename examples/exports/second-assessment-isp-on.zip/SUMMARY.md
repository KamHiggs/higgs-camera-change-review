# Higgs camera assessment — recorded decision

Assessment contract: higgs-assessment-v0.1.2

## Status

ESTABLISHED_BLOCKER

Camera: CAM-FLIR

Advisory result — no deployment approval.

Real source captures; synthetic installation, requirements, timing assumptions and cost points. No hardware or deployment approval.

## Reason and counts

```json
[]
```

## Counts

```json
{
  "condition_unresolved_evidence_rows": 0,
  "established_constraint_failures": 2,
  "normally_inapplicable_rows": 1,
  "quarantined_evidence_rows": 0,
  "unknown_constraint_evaluations": 2,
  "unresolved_premises": 0
}
```

## Established blockers

```json
[
  {
    "comparison": ">=",
    "constraint": "frame_rate",
    "limit": 45,
    "locators": [
      {
        "field_present": true,
        "locator": "/data/max_fps",
        "requested_locator": "/data/max_fps",
        "source_id": "GEN-CAM-FLIR"
      },
      {
        "field_present": true,
        "locator": "/data/required_fps",
        "requested_locator": "/data/required_fps",
        "source_id": "SYN-REQ-LINE-FAST"
      }
    ],
    "missing_fields": [],
    "source_ids": [
      "GEN-CAM-FLIR",
      "SYN-REQ-LINE-FAST"
    ],
    "status": "fail",
    "value": 24,
    "variant_id": "LINE-FAST"
  },
  {
    "comparison": ">=",
    "constraint": "frame_rate",
    "limit": 30,
    "locators": [
      {
        "field_present": true,
        "locator": "/data/max_fps",
        "requested_locator": "/data/max_fps",
        "source_id": "GEN-CAM-FLIR"
      },
      {
        "field_present": true,
        "locator": "/data/required_fps",
        "requested_locator": "/data/required_fps",
        "source_id": "SYN-REQ-LINE-SLOW"
      }
    ],
    "missing_fields": [],
    "source_ids": [
      "GEN-CAM-FLIR",
      "SYN-REQ-LINE-SLOW"
    ],
    "status": "fail",
    "value": 24,
    "variant_id": "LINE-SLOW"
  }
]
```

## Unknown constraints

```json
[
  {
    "comparison": "minimum achievable worst-case error <= limit",
    "constraint": "timing",
    "limit": 1,
    "locators": [
      {
        "field_present": true,
        "locator": "/data/timestamp_jitter_bound_ms",
        "requested_locator": "/data/timestamp_jitter_bound_ms",
        "source_id": "GEN-CAM-FLIR"
      },
      {
        "field_present": true,
        "locator": "/data/timestamp_bias_ms_by_variant/LINE-FAST",
        "requested_locator": "/data/timestamp_bias_ms_by_variant/LINE-FAST",
        "source_id": "GEN-CAM-FLIR"
      },
      {
        "field_present": true,
        "locator": "/data/speed_m_s",
        "requested_locator": "/data/speed_m_s",
        "source_id": "SYN-REQ-LINE-FAST"
      },
      {
        "field_present": true,
        "locator": "/data/max_registration_error_mm",
        "requested_locator": "/data/max_registration_error_mm",
        "source_id": "SYN-REQ-LINE-FAST"
      },
      {
        "field_present": true,
        "locator": "/data/host_jitter_bound_ms",
        "requested_locator": "/data/host_jitter_bound_ms",
        "source_id": "SYN-REQ-LINE-FAST"
      }
    ],
    "missing_fields": [
      "timestamp_jitter_bound_ms"
    ],
    "source_ids": [
      "GEN-CAM-FLIR",
      "SYN-REQ-LINE-FAST"
    ],
    "status": "unknown",
    "value": null,
    "variant_id": "LINE-FAST"
  },
  {
    "comparison": "minimum achievable worst-case error <= limit",
    "constraint": "timing",
    "limit": 0.5,
    "locators": [
      {
        "field_present": true,
        "locator": "/data/timestamp_jitter_bound_ms",
        "requested_locator": "/data/timestamp_jitter_bound_ms",
        "source_id": "GEN-CAM-FLIR"
      },
      {
        "field_present": true,
        "locator": "/data/timestamp_bias_ms_by_variant/LINE-SLOW",
        "requested_locator": "/data/timestamp_bias_ms_by_variant/LINE-SLOW",
        "source_id": "GEN-CAM-FLIR"
      },
      {
        "field_present": true,
        "locator": "/data/speed_m_s",
        "requested_locator": "/data/speed_m_s",
        "source_id": "SYN-REQ-LINE-SLOW"
      },
      {
        "field_present": true,
        "locator": "/data/max_registration_error_mm",
        "requested_locator": "/data/max_registration_error_mm",
        "source_id": "SYN-REQ-LINE-SLOW"
      },
      {
        "field_present": true,
        "locator": "/data/host_jitter_bound_ms",
        "requested_locator": "/data/host_jitter_bound_ms",
        "source_id": "SYN-REQ-LINE-SLOW"
      }
    ],
    "missing_fields": [
      "timestamp_jitter_bound_ms"
    ],
    "source_ids": [
      "GEN-CAM-FLIR",
      "SYN-REQ-LINE-SLOW"
    ],
    "status": "unknown",
    "value": null,
    "variant_id": "LINE-SLOW"
  }
]
```

## Decision-changing evidence

```json
{
  "analysis_scope": "bounded_non_voltage_synthetic",
  "cartridge_id": "camera",
  "cartridge_version": "0.1.2",
  "decision_status": "conditional_evidence_analysis",
  "deployment_qualified": false,
  "excluded_constraints": [
    "voltage"
  ],
  "execution_status": "completed",
  "full_camera_compatibility": false,
  "human_approval_recorded": false,
  "interface_version": "higgs.python-cognimap/1",
  "operation": "decision_questions",
  "qualification": "Every plan and evidence question is conditional on this non-voltage subsystem; voltage still requires independent resolution.",
  "request_identity": "1cf471429b1374f5d26290af3960a310ae72c3dff6c220e601be45e162efaf1e",
  "result": {
    "analysis_scope": "bounded_non_voltage_synthetic",
    "analysis_status": "blocked",
    "base_input_identity": "cb314743d04c6dc62c0ddb46fd1066974fe8cfa3c4819d70f430bdff269d0c3d",
    "base_unchanged": true,
    "blocker_details": [
      {
        "comparison": ">=",
        "constraint": "frame_rate",
        "limit": 45,
        "locators": [
          {
            "field_present": true,
            "locator": "/data/max_fps",
            "requested_locator": "/data/max_fps",
            "source_id": "GEN-CAM-FLIR"
          },
          {
            "field_present": true,
            "locator": "/data/required_fps",
            "requested_locator": "/data/required_fps",
            "source_id": "SYN-REQ-LINE-FAST"
          }
        ],
        "missing_fields": [],
        "source_ids": [
          "GEN-CAM-FLIR",
          "SYN-REQ-LINE-FAST"
        ],
        "status": "fail",
        "value": 24,
        "variant_id": "LINE-FAST"
      },
      {
        "comparison": ">=",
        "constraint": "frame_rate",
        "limit": 30,
        "locators": [
          {
            "field_present": true,
            "locator": "/data/max_fps",
            "requested_locator": "/data/max_fps",
            "source_id": "GEN-CAM-FLIR"
          },
          {
            "field_present": true,
            "locator": "/data/required_fps",
            "requested_locator": "/data/required_fps",
            "source_id": "SYN-REQ-LINE-SLOW"
          }
        ],
        "missing_fields": [],
        "source_ids": [
          "GEN-CAM-FLIR",
          "SYN-REQ-LINE-SLOW"
        ],
        "status": "fail",
        "value": 24,
        "variant_id": "LINE-SLOW"
      }
    ],
    "blockers": [
      "LINE-FAST: frame_rate: established failure",
      "LINE-SLOW: frame_rate: established failure"
    ],
    "cartridge_version": "0.1.2",
    "current_decision": {
      "cartridge_version": "0.1.2",
      "cost_points_exact": null,
      "decision_status": "insufficient_evidence",
      "error": null,
      "execution_status": "completed",
      "input_identity": "cb314743d04c6dc62c0ddb46fd1066974fe8cfa3c4819d70f430bdff269d0c3d",
      "request_identity": "7bff958fafca603a4874a40ae5cbcb7ceb7405deac71b1e3fd4d158c9b1ba668",
      "selected_plan": null
    },
    "decision_status": "conditional_evidence_analysis",
    "deployment_qualified": false,
    "derivation": [],
    "evidence_request": null,
    "excluded_constraints": [
      "voltage"
    ],
    "executable_configuration_promised": false,
    "explanation": "Candidate: CAM-FLIR. Current decision: insufficient_evidence.\n\nAnalysis: blocked.\n\nJitter alone cannot overcome: LINE-FAST: frame_rate: established failure; LINE-SLOW: frame_rate: established failure.\n\nLINE-FAST frame_rate: value 24 must satisfy >= 45; source locators are retained in blocker_details.\n\nLINE-SLOW frame_rate: value 24 must satisfy >= 30; source locators are retained in blocker_details.\n\nNo jitter-only request is issued as sufficient to improve or add a tied option to this decision.\n\nVoltage compatibility remains unknown outside this bounded subsystem. No jitter guarantee establishes full replacement suitability.\n\nSynthetic model only; facts are supplied, not independently authenticated.\n\nCost comparison covers established plans only; unresolved other candidates can still matter.\n\nRepresentative previews are hypothetical witnesses, not a proof of encoding over a whole region.\n\nMathematical conditions are not a guaranteed executable configuration. No supplier fact, deployment approval, or hardware qualification was created.",
    "full_camera_compatibility": false,
    "human_approval_recorded": false,
    "limitations": [
      "Voltage compatibility remains unknown outside this bounded subsystem. No jitter guarantee establishes full replacement suitability.",
      "Synthetic model only; facts are supplied, not independently authenticated.",
      "Cost comparison covers established plans only; unresolved other candidates can still matter.",
      "Representative previews are hypothetical witnesses, not a proof of encoding over a whole region."
    ],
    "model_id": "EC-SYNTHETIC-1.0",
    "policies": [],
    "regions": [],
    "remaining_unknowns": [],
    "rule_ids": [
      "R-AUTH",
      "R-U01",
      "R-TIME",
      "R-SELECT",
      "R-SERIAL",
      "R-EVIDENCE",
      "R-SIM"
    ],
    "run_kind": "conditional_evidence_analysis",
    "target": {
      "camera_id": "CAM-FLIR",
      "evidence_source_role": "synthetic_integration_characterization",
      "field": "timestamp_jitter_bound_ms",
      "locators": [
        {
          "file": "sources/GEN-CAM-FLIR.json",
          "locator": "/data/timestamp_jitter_bound_ms",
          "requested_locator": "/data/timestamp_jitter_bound_ms",
          "source_id": "GEN-CAM-FLIR",
          "source_identity": "5a01d18622fce34871579c49c44c53b5dfb7c845099364d14d0dc6c0b4f1e728"
        }
      ],
      "requested_locator": "/data/timestamp_jitter_bound_ms",
      "source_id": "GEN-CAM-FLIR",
      "source_ids": [
        "GEN-CAM-FLIR"
      ],
      "spec_revision": 1,
      "upstream_origins": [
        {
          "applicability": "APPLICABLE",
          "capture_id": "CAP-SYN-040",
          "capture_sha256": "96673c967cd256c6897c3bf2fe8b555625d76e5d0f0ef82c4da9ef457ecb5102",
          "conditions": {
            "scenario": "fictional; no real measurement or guarantee"
          },
          "entry_id": "LEDGER-CAP-SYN-040",
          "evidence_class": "synthetic_guaranteed_bound",
          "lexical_value": "null",
          "locator": "/camera_supplements/CAM-FLIR/timestamp_jitter_bound_ms",
          "minimum_payload_MB_s": null,
          "normalized_exact": null,
          "origin": "synthetic",
          "source_document_sha256": "9437f7856dbd620d3315337f85abc81ef4e43c47f3a1147a5d5efc4a9f295a3b",
          "source_id": "SYN-integration_characterization",
          "units": "ms",
          "url": null
        }
      ]
    }
  },
  "run_kind": "conditional_evidence_analysis",
  "wrapper_version": "0.1.2"
}
```

## Scope

```json
"Bounded non-voltage synthetic installation; real source captures; no full camera compatibility."
```

Full decision verification checks this deterministic view under the v0.1.2 contract. Engine reproduction alone does not. Recorded file integrity is not authorship, manufacturer truth, physical identity or engineering approval. Creation IDs/timestamps and display metadata are not authenticated. Any permitted operator note is manifest-covered but not semantically verified.
