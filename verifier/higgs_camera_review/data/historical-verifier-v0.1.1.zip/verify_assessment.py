import sys
sys.dont_write_bytecode = True
from higgs_camera_review.verification import main
if __name__ == "__main__":
    sys.exit(main())
