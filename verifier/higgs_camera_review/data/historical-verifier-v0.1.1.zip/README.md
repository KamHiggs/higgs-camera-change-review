# Separate Higgs assessment verifier 0.1.1

Obtain this package and its approved identity outside the assessment you examine. An assessment cannot authorize a replacement verifier or pin set. Use Python 3.12; no runtime pip install, network, Django, InvenTree or model is required for this CLI. Host-dependent modules are carried for software-identity comparison but are not imported by the CLI.

Extract an assessment into a separate folder. From this verifier directory:

```
python3 -B verify_assessment.py --assessment /path/to/extracted-assessment --out /path/to/new-output --level engine
python3 -B verify_assessment.py --assessment /path/to/extracted-assessment --out /path/to/another-new-output --level decision
```

Output must be new and outside the assessment. Exit 0: requested level met; exit 1: NOT_VERIFIED; exit 3: legacy engine reproduced but full-decision verification unavailable. A misuse of filesystem permissions may prevent a receipt from being written; a nonzero exit is never success.

REPRODUCED_ENGINE_OUTPUT checks manifest and externally pinned runtime, then reproduces saved projection outputs. It intentionally does not establish consistency among all representations. VERIFIED_RECORDED_DECISION additionally reconstructs raw snapshot → typed inputs and identity bindings → pinned mapper projection → engine outputs → versioned summary. The exact software and summary contracts must match this version. Historical 0.1.0 exports can only receive the engine assurance and explicit full-verification-unavailable label; their embedded replay.py is never executed.

This establishes agreement with pinned software and recorded declarations, not manufacturer truth, inventory authenticity, physical compatibility, complete evidence, a general tamper-proof audit trail or an independent correctness oracle. A coherent rewrite of all inventory declarations is outside these identity guarantees. The receiver must trust the separately obtained verifier and its pin set. New integration/verifier license remains proposed; see LICENSE_REVIEW.md. Local review candidate, not approved for publication.
