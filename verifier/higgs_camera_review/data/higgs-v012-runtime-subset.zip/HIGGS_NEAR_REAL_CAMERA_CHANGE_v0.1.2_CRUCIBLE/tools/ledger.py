"""One adjudicated worksheet; immutable capture records substantiate its rows."""
from fractions import Fraction
from common import ROOT, load, loads, semantic_sha, WrapperError, reference

# v0.1.2 (C2R-01): condition keys are a closed vocabulary. Executable keys are
# enforced prerequisites. Annotation keys are reviewer-facing prose that is
# preserved but never evaluated, so it can never qualify or disqualify a value.
# Any other key is refused; spelling is never corrected and intent never inferred.
EXECUTABLE_CONDITIONS={'mode','premises','minimum_payload_MB_s'}
ANNOTATION_CONDITIONS={'source_wording_qualification','power_path_qualification','packaging_scope','scenario'}
BUDGET_POINTER='/data/link_capacity_MB_s'

def validate_conditions(e,refs):
    c=e.get('conditions')
    if not isinstance(c,dict):raise WrapperError('CONDITION_TYPE','Conditions must be an object',refs)
    unknown=sorted(set(c)-EXECUTABLE_CONDITIONS-ANNOTATION_CONDITIONS)
    if unknown:raise WrapperError('UNRECOGNIZED_CONDITION','Condition keys without defined semantics are refused, not ignored or corrected: '+', '.join(unknown),refs)
    for k in sorted(ANNOTATION_CONDITIONS & set(c)):
        if not isinstance(c[k],str):raise WrapperError('CONDITION_TYPE','Annotation '+k+' must be text; annotations are never enforced',refs)
    for k in ('mode','premises'):
        if k in c and not isinstance(c[k],dict):raise WrapperError('CONDITION_TYPE',k+' condition must be an object',refs)
    if 'minimum_payload_MB_s' in c:
        m=c['minimum_payload_MB_s']
        if isinstance(m,bool) or not isinstance(m,(int,Fraction)) or m<0:
            raise WrapperError('CONDITION_TYPE','minimum_payload_MB_s must be a nonnegative exact number',refs)
        if (e.get('destination') or {}).get('pointer')==BUDGET_POINTER:
            raise WrapperError('CONDITION_CIRCULAR','A payload budget cannot itself be conditioned on a payload budget',refs)

def required_units(field):
    # Units already encoded by the fixed retained schema; no unit conversion.
    if 'timestamp_bias_ms_by_variant/' in field or 'offset_ms_by_variant/' in field:return 'ms'
    leaf=field.split('/')[-1]
    return {'image_width_px':'px','image_height_px':'px','max_fps':'fps','required_fps':'fps',
        'power_W':'W','power_budget_W':'W','supply_voltage_V':'VDC','field_of_view_mm':'mm',
        'host_jitter_bound_ms':'ms','link_capacity_MB_s':'MB/s','max_mm_per_pixel':'mm/px',
        'max_registration_error_mm':'mm','speed_m_s':'m/s','migration_cost_points':'synthetic_cost_points',
        'timestamp_jitter_bound_ms':'ms','typical_timestamp_jitter_ms':'ms','bytes_per_pixel':'bytes/px',
        'default_offset_ms':'ms','offset_ms':'ms','observations':'mm','recorded_limit':'mm'
        }.get(leaf,'not_applicable')

def read_ledger(root=ROOT):
    path=root/'evidence/EVIDENCE_LEDGER.json'; d=load(path)
    cap_path=root/'evidence/SOURCE_CAPTURES.json'; cap_doc=load(cap_path)
    caps={}; entries={}
    for c in cap_doc['captures']:
        if c['capture_id'] in caps:raise WrapperError('DUPLICATE_CAPTURE','Duplicate capture identity',[c['capture_id']])
        caps[c['capture_id']]=c
    for e in d['entries']:
        eid=e['id']; cid=e['capture_id']; refs=[eid,cid,e.get('source_id'),e.get('locator')]
        if eid in entries:raise WrapperError('DUPLICATE_ENTRY','Duplicate ledger identity',refs)
        if cid not in caps:raise WrapperError('CAPTURE_MISSING','Capture is unavailable',refs)
        c=caps[cid]
        if e['capture_sha256']!=semantic_sha(c):raise WrapperError('CAPTURE_IDENTITY','Capture differs from adjudicated identity',refs)
        for k in ['source_id','subject','field','lexical_value','units','evidence_class','conditions','locator']:
            if e.get(k)!=c.get(k):raise WrapperError('CAPTURE_BINDING','Ledger/capture mismatch at '+k,refs)
        validate_conditions(e,refs)
        if e.get('units')!=required_units(e['field']):
            raise WrapperError('UNIT_CONTRACT','Units differ from the fixed retained field contract; no implicit conversion',refs)
        if e['source_id'] not in d['sources']:raise WrapperError('SOURCE_MISSING','Unknown source identity',refs)
        if c.get('source_document_sha256')!=d['sources'][e['source_id']].get('sha256'):
            raise WrapperError('SOURCE_BINDING','Source/capture document identity mismatch',refs)
        val=loads(e['lexical_value'])
        if semantic_sha(val)!=semantic_sha(e['normalized_exact']):raise WrapperError('NORMALIZATION','Identity normalization changed numerical/typed value',refs)
        state=e['admission_state']
        if state not in ['ADMITTED','QUARANTINED','EXCLUDED']:raise WrapperError('ADMISSION_STATE','Unknown admission state',refs)
        if not e.get('adjudication_reason'):raise WrapperError('ADJUDICATION','Reason is required',refs)
        dest=e.get('destination')
        if state=='ADMITTED':
            if not dest or not dest.get('pointer','').startswith('/data/') or dest.get('record_id') not in d['record_templates']:
                raise WrapperError('DESTINATION','Admitted field lacks a declared destination',refs)
            if d['record_templates'][dest['record_id']]['subject_id']!=e['subject'] or dest['pointer'] not in ['/data/'+e['field'],e['field']]:
                raise WrapperError('DESTINATION_BINDING','Source subject/field does not match admitted destination',refs)
            if dest['pointer'].endswith('/supply_range_V'):
                raise WrapperError('VOLTAGE_SCOPE','No manufacturer voltage tolerance is admitted in this experiment',refs)
            bound=dest['pointer'].split('/')[-1]
            if bound in ['power_W','timestamp_jitter_bound_ms'] and val is not None:
                permitted={'maximum','guaranteed_upper_bound','synthetic_guaranteed_bound'}
                if e['evidence_class'] not in permitted:
                    raise WrapperError('BOUND_EVIDENCE_CLASS','Typical/nominal/sample evidence cannot fill a guaranteed/max slot',refs)
            if e['evidence_class'].startswith('synthetic') and d['sources'][e['source_id']]['origin']!='synthetic':
                raise WrapperError('SYNTHETIC_ORIGIN','Synthetic class cannot relabel a public source',refs)
            if d['sources'][e['source_id']]['origin']=='public_manufacturer_capture':
                required=set()
                if e['field'] in ['image_width_px','image_height_px','max_fps']:required={'pixel_format','resolution_context','power_path'}
                if e['field']=='power_W':required={'power_path'}
                if e['subject']=='CAM-FLIR' and e['field']=='max_fps':required|={'isp_enabled','adc_bits','binning','decimation','firmware'}
                mode=e['conditions'].get('mode',{})
                if any(k not in mode or mode[k] is None for k in required):
                    raise WrapperError('MATERIAL_CONDITION','Admitted fact lacks a required operating qualifier',refs)
        elif not e.get('quarantine_reason'):
            raise WrapperError('QUARANTINE_REASON','Non-admission requires an explicit reason',refs)
        entries[eid]=e
    if set(d['declared_test_ids'])!={k for k,v in d['record_templates'].items() if v['kind']=='test_record'}:
        raise WrapperError('TEST_INVENTORY','Declared tests and templates disagree')
    return d,entries,caps

def applicability(entry,scenario,budgets,variant_ids):
    """v0.1.2 (C2R-02): classify one admitted row before any value is combined.

    INAPPLICABLE: some condition is established and unmet (takes precedence).
    UNRESOLVED:   some required condition value is not established.
    APPLICABLE:   every executable condition is established and satisfied.
    Annotation keys are never consulted here.
    """
    conditions=entry['conditions']; missing=[]; mismatch=[]
    cam=entry['subject']; mode=scenario['camera_modes'].get(cam,{})
    for k,wanted in conditions.get('mode',{}).items():
        actual=mode.get(k)
        if actual is None:missing.append(cam+'.'+k)
        elif type(actual)!=type(wanted) or actual!=wanted:mismatch.append(cam+'.'+k)
    for k,wanted in conditions.get('premises',{}).items():
        actual=scenario['premises'].get(k)
        if actual is None:missing.append(k)
        elif actual!=wanted:mismatch.append(k)
    minimum=conditions.get('minimum_payload_MB_s')
    if minimum is not None:
        # Quantitative applicability is checked against ledger-derived budgets,
        # never against a label or prose declaration.
        for v in variant_ids:
            budget=budgets.get(v); where='SYN-REQ-'+v+BUDGET_POINTER
            if budget is None:missing.append(where)
            elif budget<minimum:mismatch.append(where+' below source minimum_payload_MB_s')
    state='INAPPLICABLE' if mismatch else 'UNRESOLVED' if missing else 'APPLICABLE'
    return state,missing,mismatch

def project_values(d,entries,scenario):
    values={k:{} for k in d['record_templates']}; origins={k:{} for k in values}; held=[]
    def held_row(e,state,**extra):
        return dict(entry_id=e['id'],state=state,destination=e.get('destination'),
            source_id=e['source_id'],capture_id=e['capture_id'],capture_sha256=e['capture_sha256'],
            origin=d['sources'][e['source_id']]['origin'],url=d['sources'][e['source_id']].get('url'),
            lexical_value=e['lexical_value'],units=e['units'],evidence_class=e['evidence_class'],
            conditions=e['conditions'],locator=e['locator'],**extra)
    admitted=[]
    for e in entries.values():
        if e['admission_state']!='ADMITTED':
            held.append(held_row(e,e['admission_state'],reason=e['quarantine_reason']));continue
        admitted.append(e)
    # Budgets are resolved first (they carry no payload condition; enforced by
    # validate_conditions), then every other destination. Within each phase all
    # rows are classified before any value, consensus or conflict is decided.
    budgets={}
    for phase in ([e for e in admitted if e['destination']['pointer']==BUDGET_POINTER],
                  [e for e in admitted if e['destination']['pointer']!=BUDGET_POINTER]):
        groups={}
        for e in phase:
            state,missing,mismatch=applicability(e,scenario,budgets,d['variant_ids'])
            groups.setdefault((e['destination']['record_id'],e['destination']['pointer']),[]).append((e,state,missing,mismatch))
            if state=='INAPPLICABLE':
                held.append(held_row(e,'CONDITION_INAPPLICABLE',applicability=state,missing=missing,mismatch=mismatch,
                    reason='An established condition is unmet; this row neither supplies nor contradicts the field'))
            elif state=='UNRESOLVED':
                held.append(held_row(e,'CONDITION_UNRESOLVED',applicability=state,missing=missing,mismatch=mismatch,
                    reason='Applicability not established; retained and considered against applicable values'))
        for (rid,ptr),rows in groups.items():
            applicable=[r[0] for r in rows if r[1]=='APPLICABLE']
            unresolved=[r[0] for r in rows if r[1]=='UNRESOLVED']
            for e in applicable[1:]:
                if semantic_sha(e['normalized_exact'])!=semantic_sha(applicable[0]['normalized_exact']):
                    raise WrapperError('ADMITTED_CONFLICT','Conflicting applicable admitted values',[
                        {'entry_id':x['id'],'capture_id':x['capture_id'],'source_id':x['source_id'],'locator':x['locator']} for x in applicable])
            if not applicable:continue  # field stays unknown; unresolved/inapplicable rows are already held
            val=applicable[0]['normalized_exact']
            differing=[e for e in unresolved if semantic_sha(e['normalized_exact'])!=semantic_sha(val)]
            if differing:
                # An unresolved row could supply a different value. Do not prefer the
                # applicable value merely to obtain an answer: withhold the field.
                values[rid][ptr]=None
                held.append({'entry_id':differing[0]['id'],'entry_ids':[x['id'] for x in applicable+differing],'state':'UNRESOLVED_ALTERNATE',
                    'destination':{'record_id':rid,'pointer':ptr},
                    'reason':'Applicable value withheld: an admitted row with unresolved applicability states a different value'})
                continue
            values[rid][ptr]=val
            for e in applicable:
                origins[rid].setdefault(ptr,[]).append({'entry_id':e['id'],'source_id':e['source_id'],
                    'capture_id':e['capture_id'],'capture_sha256':e['capture_sha256'],'origin':d['sources'][e['source_id']]['origin'],
                    'url':d['sources'][e['source_id']].get('url'),'source_document_sha256':d['sources'][e['source_id']].get('sha256'),
                    'locator':e['locator'],'lexical_value':e['lexical_value'],'normalized_exact':e['normalized_exact'],
                    'units':e['units'],'evidence_class':e['evidence_class'],'conditions':e['conditions'],
                    'minimum_payload_MB_s':e['conditions'].get('minimum_payload_MB_s'),'applicability':'APPLICABLE'})
        if not budgets:
            budgets={v:values['SYN-REQ-'+v].get(BUDGET_POINTER) for v in d['variant_ids']}
    return values,origins,held
