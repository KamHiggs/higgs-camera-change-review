"""Projection from the sole adjudicated ledger. No admission table fallback."""
from pathlib import Path
import copy
from common import dump, semantic_sha, WrapperError

def assign(data,pointer,value):
    bits=[x.replace('~1','/').replace('~0','~') for x in pointer.split('/')[2:]]
    cur=data
    for part in bits[:-1]:cur=cur.setdefault(part,{})
    cur[bits[-1]]=copy.deepcopy(value)

def materialize(output,gate,scenario,ledger,values,origins):
    if not gate['analysis_allowed']:raise WrapperError('APPLICABILITY_REFUSED','No full calculation under missing/unsupported premises')
    folder=Path(output);folder.mkdir(parents=True,exist_ok=False)
    records=[];inv=[]
    for rid,template in ledger['record_templates'].items():
        rec=copy.deepcopy(template);data={}
        for ptr,value in values[rid].items():assign(data,ptr,value)
        if rec['kind']=='camera':
            for field in ['image_width_px','image_height_px','max_fps','power_W','transport','timestamp_jitter_bound_ms']:
                data.setdefault(field,None)
            # Unknown is preserved for the ordinary solver. Never make up [5,5].
            data['supply_range_V']=None
        rec['data']=data;rec['field_origins']=copy.deepcopy(origins[rid])
        rec['projection_scope']='bounded_non_voltage_synthetic'
        records.append(rec);rel='sources/'+rid+'.json';dump(folder/rel,rec);inv.append({'source_id':rid,'path':rel})
    case={'schema_version':'1.0','synthetic':scenario['synthetic'],'case_id':ledger['case_id']+'-'+scenario['scenario_id'],
        'variant_ids':ledger['variant_ids'],'candidate_camera_ids':ledger['candidate_camera_ids'],
        'base_firmware_revision':ledger['base_firmware_revision'],'source_inventory':inv,
        'objective':'Bounded synthetic non-voltage calculation; all voltage compatibility unresolved',
        'analysis_scope':'bounded_non_voltage_synthetic','excluded_constraints':['voltage']}
    dump(folder/'case.json',case)
    trace={'schema_version':'0.1.2','scenario_identity':semantic_sha(scenario),'ledger_identity':semantic_sha(ledger),
        'input_source_references':gate['source_references'],
        'field_origins':origins,'withheld_evidence':gate['withheld_evidence'],
        'template_origin':'evidence/EVIDENCE_LEDGER.json#/record_templates',
        'derived_fields':{'camera.supply_range_V':{'value':None,'origin':'explicit R2-06 exclusion; not a manufacturer range'},
                          'case.source_inventory':'deterministic projection of declared templates; no evidence authority created'},
        'excluded_constraints':gate['excluded_constraints'],'full_camera_compatibility':False}
    return case,records,trace
