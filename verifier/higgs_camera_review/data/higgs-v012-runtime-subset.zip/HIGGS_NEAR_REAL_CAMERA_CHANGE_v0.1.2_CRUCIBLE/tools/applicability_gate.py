"""Finite applicability predicates for one declared synthetic subsystem.

No expected answers, golden files, reviewer records or verdict inputs are read.
"""
from common import ROOT, load, reference, WrapperError
from ledger import read_ledger, project_values

REQUIRED={'pixel_format':'Mono8','bytes_per_pixel':1,'resolution_context':'declared_dimensions',
          'transport':'USB3-Vision','compression':False,'timestamp_event':'synthetic_registration_event',
          'clock_behavior':'additive_offset','registration_model':'additive_bias_offset_bounded_jitter',
          'throughput_basis':'usable_payload_budget'}

def evaluate(scenario_path,root=ROOT):
    scenario=load(scenario_path);d,entries,caps=read_ledger(root)
    allowed={'scenario_id','synthetic','analysis_scope','excluded_constraints','premises','camera_modes'}
    if set(scenario)-allowed:raise WrapperError('SCENARIO_FIELDS','Unsupported scenario keys',sorted(set(scenario)-allowed))
    established=[];missing=[];conflicts=[];unsupported=[]
    refs=[reference(scenario_path),reference(root/'evidence/EVIDENCE_LEDGER.json'),reference(root/'evidence/SOURCE_CAPTURES.json')]
    def fact(name,value,where):return {'premise':name,'value':value,'reference':dict(refs[0],pointer=where)}
    if scenario.get('synthetic') is not True or d.get('synthetic') is not True:
        unsupported.append({'premise':'synthetic','reason':'Explicit synthetic world required; contradictory flags are never overwritten','references':refs[:2]})
    if scenario.get('analysis_scope')!='bounded_non_voltage_synthetic' or scenario.get('excluded_constraints')!=['voltage'] or d.get('excluded_constraints')!=['voltage']:
        unsupported.append({'premise':'scope','reason':'Only adopted non-voltage bounded scope is implemented','references':refs[:2]})
    premises=scenario.get('premises',{})
    if not isinstance(premises,dict):raise WrapperError('PREMISES_TYPE','Premises must be an object')
    for k,wanted in REQUIRED.items():
        v=premises.get(k); row=fact(k,v,'/premises/'+k)
        if v is None:missing.append(row)
        elif type(v)!=type(wanted) or v!=wanted:
            unsupported.append(dict(row,reason='Retained representation supports only '+str(wanted)))
        else:established.append(row)
    extra=set(premises)-set(REQUIRED)
    if extra:unsupported.append({'premise':'unmodeled_premise_keys','reason':'Consequential extra premises cannot be silently ignored','keys':sorted(extra),'references':refs[:1]})
    modes=scenario.get('camera_modes',{})
    if not isinstance(modes,dict):raise WrapperError('MODE_TYPE','camera_modes must be an object')
    scenario=dict(scenario,premises=premises,camera_modes=modes)
    base_missing=bool(missing)
    for cid in d['candidate_camera_ids']:
        mode=modes.get(cid,{})
        if not isinstance(mode,dict):raise WrapperError('MODE_TYPE','Camera mode must be an object',[cid])
        keys=['pixel_format','resolution_context','power_path']
        if cid=='CAM-FLIR':keys+=['isp_enabled','adc_bits','binning','decimation','firmware']
        if set(mode)-set(keys):unsupported.append({'premise':cid,'reason':'Unmodeled camera condition','keys':sorted(set(mode)-set(keys)),'references':refs[:1]})
        for k in keys:
            val=mode.get(k); row=fact(cid+'.'+k,val,'/camera_modes/'+cid+'/'+k)
            if val is None:missing.append(row)
            else:established.append(row)
        if mode.get('pixel_format') is not None and mode['pixel_format']!=premises.get('pixel_format'):
            conflicts.append({'premise':cid+'.pixel_format','reason':'Camera and system pixel declarations differ','references':refs[:1]})
        if mode.get('power_path') not in [None,'USB']:
            unsupported.append({'premise':cid+'.power_path','reason':'This ledger only admits this synthetic USB power path','references':refs[:1]})
    unknown_cameras=set(modes)-set(d['candidate_camera_ids'])
    if unknown_cameras:unsupported.append({'premise':'camera_modes','reason':'Undeclared camera identities','ids':sorted(unknown_cameras),'references':refs[:1]})
    values,origins,held=project_values(d,entries,scenario)
    required_variant=['field_of_view_mm','max_mm_per_pixel','required_fps','link_capacity_MB_s','power_budget_W','speed_m_s','max_registration_error_mm','host_jitter_bound_ms','transport','supply_voltage_V']
    for vid in d['variant_ids']:
        rid='SYN-REQ-'+vid
        for name in required_variant:
            ptr='/data/'+name
            if values[rid].get(ptr) is None:
                missing.append({'premise':rid+ptr,'reason':'Consequential synthetic requirement not established','reference':refs[1]});base_missing=True
            elif name=='transport' and values[rid][ptr]!=premises.get('transport'):
                conflicts.append({'premise':rid+ptr,'reason':'Ledger and declared transport differ','references':refs[:2]})
    for cid in d['candidate_camera_ids']:
        rid='GEN-'+cid
        if values[rid].get('/data/bytes_per_pixel')!=premises.get('bytes_per_pixel'):
            conflicts.append({'premise':rid+'/data/bytes_per_pixel','reason':'Ledger and mode byte size differ','references':refs[:2]})
        for ptr in ['/data/image_width_px','/data/image_height_px','/data/max_fps','/data/power_W','/data/transport','/data/timestamp_jitter_bound_ms']:
            if values[rid].get(ptr) is None:
                # These are representable unknown facts, unlike missing clock physics.
                continue
    outside=any(x['premise'] in ['synthetic','clock_behavior','timestamp_event','registration_model'] for x in unsupported)
    allowed_analysis=not (unsupported or conflicts or base_missing)
    verdict='OUTSIDE_MODEL' if outside else 'BOUNDED_SUBSYSTEM_ONLY'
    result={'scenario_id':scenario.get('scenario_id'),'verdict':verdict,'analysis_allowed':allowed_analysis,
        'analysis_scope':'bounded_non_voltage_synthetic','excluded_constraints':[{'constraint':'voltage','evidence_status':'unknown','reason':'No source-supported voltage tolerance; excluded by adopted R2-06, not passed'}],
        'established_premises':established,'missing_premises':missing,'conflicting_premises':conflicts,
        'unsupported_modeling_assumptions':unsupported,'withheld_evidence':held,'source_references':refs,
        'meaning':'Permission for a bounded software calculation only; no full replacement decision, hardware qualification or deployment approval'}
    return result,scenario,d,entries,values,origins
