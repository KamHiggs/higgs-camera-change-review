"""Fixed, explicit voltage exclusion around an unchanged retained calculator.

This is a single-process context, not a plugin interface or concurrency service.
It removes exactly one unknown constraint from the subsystem eligibility
summary. Its original unknown row is retained. All other equations, precedence,
source authority, simulation and NumericEncodingError handling remain retained.
"""
from contextlib import contextmanager
import copy, sys
from common import ROOT, WrapperError
RUNTIME=ROOT/'runtime/higgs_camera_change_review_v0_3_0_rc1'
sys.path.insert(0,str(RUNTIME))
import engine
import camera_cognimap as cm

@contextmanager
def scope(case):
    if case.get('synthetic') is not True or case.get('analysis_scope')!='bounded_non_voltage_synthetic' or case.get('excluded_constraints')!=['voltage']:
        raise WrapperError('ADAPTER_SCOPE','Explicit adopted voltage-only exclusion required')
    original=engine.evaluate
    def bounded_evaluate(*args,**kwargs):
        ev=original(*args,**kwargs)
        voltage=[x for x in ev['constraints'] if x['constraint']=='voltage']
        if len(voltage)!=1 or voltage[0]['status']!='unknown':
            raise WrapperError('ADAPTER_VOLTAGE','Exclusion adapter requires genuinely unknown voltage evidence')
        ev['excluded_constraints']=[dict(voltage[0],exclusion_reason='Outside adopted bounded scope; not a pass')]
        ev['constraints']=[x for x in ev['constraints'] if x['constraint']!='voltage']
        ev['blockers']=[x['constraint']+': established failure' for x in ev['constraints'] if x['status']=='fail']
        ev['unknowns']=[x['constraint']+': missing/conflicting '+', '.join(x['missing_fields']) for x in ev['constraints'] if x['missing_fields']]
        ev['status']='infeasible' if ev['blockers'] else 'unknown' if any(x['status']=='unknown' for x in ev['constraints']) else 'feasible'
        ev['analysis_scope']='bounded_non_voltage_synthetic'
        return ev
    engine.evaluate=bounded_evaluate
    try:yield
    finally:engine.evaluate=original

def label(value):
    if isinstance(value,dict):
        if 'R-VOLT' in value.get('rule_ids',[]):
            value['rule_ids']=[x for x in value['rule_ids'] if x!='R-VOLT']
            value['excluded_rule_ids']=['R-VOLT']
        if {'camera_id','policy','offset_ms_by_variant'}<=set(value):
            value.update(analysis_scope='bounded_non_voltage_synthetic',voltage_compatibility='unknown_excluded',full_camera_compatibility=False)
        for v in list(value.values()):label(v)
    elif isinstance(value,list):
        for v in value:label(v)

def execute(operation,camera_id,case,records,trace):
    base={'model_id':cm.CAMERA_MODEL,'case_data':case,'source_records':records}
    inputs=base if operation=='analyze' else {'camera_id':camera_id,'base':base}
    with scope(case):
        result=cm.execute('camera','evaluate' if operation=='analyze' else 'decision_questions',inputs)
    result.update(wrapper_version='0.1.2',analysis_scope='bounded_non_voltage_synthetic',excluded_constraints=['voltage'],full_camera_compatibility=False,
                  qualification='Every plan and evidence question is conditional on this non-voltage subsystem; voltage still requires independent resolution.')
    label(result)
    if result.get('result') and operation=='analyze':
        report=result['result']['report'];report.update(analysis_scope=result['analysis_scope'],full_camera_compatibility=False,provenance=trace)
        report['limitations'].insert(0,'VOLTAGE EXCLUDED AND UNKNOWN. This is not a full camera replacement verdict.')
    if result.get('result') and operation=='questions':
        q=result['result'];q.update(analysis_scope=result['analysis_scope'],excluded_constraints=['voltage'],full_camera_compatibility=False)
        q['limitations'].insert(0,'Voltage compatibility remains unknown outside this bounded subsystem. No jitter guarantee establishes full replacement suitability.')
        origins=trace['field_origins'].get('GEN-'+camera_id,{}).get('/data/timestamp_jitter_bound_ms',[])
        q['target']['evidence_source_role']='synthetic_integration_characterization'
        q['target']['upstream_origins']=origins
        for policy in q.get('policies',[]):policy['equation_reference']='docs/BOUNDED_ADAPTER_CONTRACT.md'
        request=q.get('evidence_request')
        if request:
            request['evidence_source_role']='integration_owner'
            request['upstream_origins']=origins
            request['text']='Ask the integration owner for an applicable guaranteed upper bound for '+camera_id+' timestamp jitter in ms, tied to the declared event, clock behavior and variant conditions. The slot is synthetic integration characterization, not a recovered manufacturer guarantee. Finite samples, typical values and PASS statements remain insufficient. If such a guarantee cannot be justified, retain unknown or revisit model applicability. Voltage compatibility remains outside this bounded result.'
            request['source_requirements']='Traceable authoritative integration evidence under declared operating premises; no vendor publication or obtainable proof is presumed.'
        from decision_questions import _explanation
        q['explanation']=_explanation(q)
    return result
