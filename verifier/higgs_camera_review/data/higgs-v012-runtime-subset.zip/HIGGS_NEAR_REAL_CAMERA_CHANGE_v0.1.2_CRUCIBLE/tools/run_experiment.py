#!/usr/bin/env python3
"""Near-real v0.1.2: bounded offline projection, not hardware qualification."""
import argparse, sys, json, html
from pathlib import Path
sys.dont_write_bytecode=True
from common import ROOT, load, dump, dumps, fresh_output, WrapperError
from applicability_gate import evaluate
from materialize_case import materialize

def emit_display(path,value):
    # Retained report displays intentionally contain finite floats. Do not feed
    # these rendered values back into input normalization or exact analysis.
    with Path(path).open('x',encoding='utf-8') as f:json.dump(value,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')

def run(args):
    scenario=(ROOT/args.scenario).resolve()
    if ROOT not in scenario.parents:raise WrapperError('SCENARIO_PATH','Scenario must be inside this candidate')
    gate,s,d,entries,values,origins=evaluate(scenario)
    if args.command=='preflight':print(dumps(gate));return 0 if gate['analysis_allowed'] else 3
    out=fresh_output(args.out,[ROOT])
    # A refusal is an output record too; no source files are changed.
    out.mkdir(parents=True,exist_ok=False);dump(out/'applicability.json',gate)
    if not gate['analysis_allowed']:
        dump(out/'refusal.json',{'execution_status':'unsupported','decision_status':None,'applicability':gate});return 3
    case,records,trace=materialize(out/'generated_case',gate,s,d,values,origins)
    dump(out/'materialization_trace.json',trace)
    from bounded_adapter import execute
    result=execute(args.command,args.camera,case,records,trace)
    target=out/('analysis' if args.command=='analyze' else 'questions');target.mkdir()
    from questions_cli import exact_export
    # exact_export preserves question rational values; finite retained display
    # floats are allowed here only after the unchanged solver has decided.
    emit_display(target/'result.json',exact_export(result))
    if result.get('result') and args.command=='analyze':
        from reporting import view,revalidation
        report=result['result']['report']
        # Provenance has exact inputs; serialize the appendix separately, not
        # through native report numeric rendering.
        provenance=report.pop('provenance')
        report['provenance_sidecar']='../materialization_trace.json'
        emit_display(target/'report.json',report)
        appendix='<h2>Bounded scope and field provenance</h2><p>Voltage is unknown and excluded. Public captures and synthetic inputs are distinct below.</p><pre>'+html.escape(dumps(provenance))+'</pre>'
        (target/'engineering_review.html').write_text(view(report)+appendix,encoding='utf-8')
        (target/'revalidation_plan.md').write_text(revalidation(report),encoding='utf-8')
    elif result.get('result'):
        (target/'explanation.md').write_text(result['result']['explanation']+'\n',encoding='utf-8')
    print(json.dumps({'execution_status':result['execution_status'],'decision_status':result['decision_status'],'analysis_scope':result['analysis_scope'],'output':str(out)}))
    if result['execution_status']!='completed':return {'numeric_encoding_error':4,'input_error':2,'unsupported':3}.get(result['execution_status'],5)
    if args.command=='questions' and result['result']['current_decision']['execution_status']=='numeric_encoding_error':return 4
    return 3 if args.command=='questions' and result['result']['analysis_status']=='unsupported' else 0

def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('command',choices=['preflight','analyze','questions'])
    p.add_argument('--scenario',default='scenarios/A_compatible.json');p.add_argument('--out');p.add_argument('--camera',default='CAM-FLIR');args=p.parse_args(argv)
    if args.command!='preflight' and not args.out:p.error('--out is required and must be a fresh directory outside the candidate')
    try:return run(args)
    except WrapperError as e:
        print(json.dumps({'execution_status':'input_error','decision_status':None,'code':e.code,'error':str(e),'references':e.references},ensure_ascii=False),file=sys.stderr);return 2
    except (OSError,ValueError,KeyError,TypeError) as e:
        print(json.dumps({'execution_status':'input_error','decision_status':None,'code':'INPUT_OR_PROJECTION_ERROR','error':type(e).__name__+': '+str(e)},ensure_ascii=False),file=sys.stderr);return 2

if __name__=='__main__':sys.exit(main())
