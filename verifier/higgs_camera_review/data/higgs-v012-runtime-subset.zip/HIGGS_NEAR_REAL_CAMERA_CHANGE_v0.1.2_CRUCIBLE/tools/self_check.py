#!/usr/bin/env python3
"""Small semantic three-way check. Logs survive failure; no prior work removed."""
from pathlib import Path
import sys,tempfile,subprocess,json
sys.dont_write_bytecode=True
from common import ROOT,load,fresh_output
sys.path.insert(0,str(ROOT/'tests'))
import assertions

def main():
    # Resolve the stock platform temp alias before passing it to the retained
    # paths. The directory is newly created by this invocation and is retained.
    out=Path(tempfile.mkdtemp(prefix='higgs-v012-selfcheck-')).resolve()
    results=[]
    try:
        for name,check in [('A_compatible',assertions.compatible),('B_slow',assertions.slow),('C_unknown',assertions.unknown)]:
            for op in ['analyze','questions']:
                dest=out/(name+'-'+op)
                cmd=[sys.executable,'-B',str(ROOT/'tools/run_experiment.py'),op,'--scenario','scenarios/'+name+'.json','--out',str(dest)]
                p=subprocess.run(cmd,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60)
                (out/(name+'-'+op+'.stdout')).write_bytes(p.stdout);(out/(name+'-'+op+'.stderr')).write_bytes(p.stderr)
                results.append({'command':cmd,'exit':p.returncode})
                assert p.returncode==(3 if name=='C_unknown' and op=='questions' else 0),p.stderr.decode()
            a=out/(name+'-analyze');q=out/(name+'-questions')
            check(load(a/'applicability.json'),load(a/'analysis/report.json'),load(q/'questions/result.json')['result'])
        result={'status':'PASS','semantic_cases':3,'child_cli_invocations':6,'output':str(out),'commands':results}
        code=0
    except Exception as exc:
        result={'status':'FAIL','error':type(exc).__name__+': '+str(exc),'output':str(out),'commands':results};code=1
    (out/'SELF_CHECK_RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));return code
if __name__=='__main__':sys.exit(main())
