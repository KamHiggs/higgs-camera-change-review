"""Exact, bounded JSON and fresh-output helpers. Standard library only."""
from pathlib import Path
from fractions import Fraction
from decimal import Decimal, InvalidOperation
import json, hashlib, re

ROOT = Path(__file__).resolve().parents[1]
class WrapperError(ValueError):
    def __init__(self, code, message, references=()):
        super().__init__(message); self.code=code; self.references=list(references)

def exact_number(token):
    if len(token)>256:
        raise WrapperError('NUMERIC_INPUT', 'Numeric token too long')
    try:
        d=Decimal(token)
        if not d.is_finite() or abs(d.as_tuple().exponent)>512:
            raise WrapperError('NUMERIC_INPUT', 'Nonfinite or excessive exponent')
        q=Fraction(d)
        if q.numerator.bit_length()>512 or q.denominator.bit_length()>512:
            raise WrapperError('NUMERIC_INPUT', 'Numeric magnitude/precision limit exceeded')
        return int(q) if q.denominator==1 else q
    except InvalidOperation as exc:
        raise WrapperError('NUMERIC_INPUT','Invalid numeric token') from exc

def pairs(rows):
    result={}
    for k,v in rows:
        if k in result: raise WrapperError('DUPLICATE_KEY','Duplicate JSON key: '+k)
        result[k]=v
    if set(result)=={'$rational'}:
        r=result['$rational']
        if not isinstance(r,list) or len(r)!=2 or not all(isinstance(x,str) and re.fullmatch(r'-?\d{1,155}',x) for x in r):
            raise WrapperError('NUMERIC_INPUT','Invalid exact rational encoding')
        try:q=Fraction(int(r[0]),int(r[1]))
        except ZeroDivisionError as exc:raise WrapperError('NUMERIC_INPUT','Zero denominator') from exc
        if q.numerator.bit_length()>512 or q.denominator.bit_length()>512:raise WrapperError('NUMERIC_INPUT','Rational exceeds numeric contract')
        return q
    return result

def loads(text):
    def bad(token):raise WrapperError('NUMERIC_INPUT','Nonfinite token: '+token)
    return json.loads(text,parse_float=exact_number,parse_int=exact_number,parse_constant=bad,object_pairs_hook=pairs)

def load(path):
    p=Path(path)
    if p.stat().st_size>2_000_000:raise WrapperError('INPUT_SIZE','JSON file exceeds bounded input size',[str(p)])
    return loads(p.read_text(encoding='utf-8'))

def token(q):
    q=Fraction(q); d=q.denominator; twos=fives=0
    while d%2==0:d//=2;twos+=1
    while d%5==0:d//=5;fives+=1
    if d!=1:return '{"$rational":['+json.dumps(str(q.numerator))+','+json.dumps(str(q.denominator))+']}'
    places=max(twos,fives); n=q.numerator*(2**(places-twos))*(5**(places-fives))
    if not places:return str(n)
    s=str(abs(n)).zfill(places+1);return ('-' if n<0 else '')+s[:-places]+'.'+s[-places:]

def dumps(value, level=0):
    # Numbers are never routed through binary float. Tagged nondecimal rationals
    # are used only in wrapper/decision outputs, not the retained input schema.
    if isinstance(value,Fraction):return token(value)
    if type(value) is float:raise WrapperError('BINARY_FLOAT','Binary float not allowed in exact wrapper inputs')
    if value is None or type(value) in (bool,int,str):return json.dumps(value,ensure_ascii=False,allow_nan=False)
    if isinstance(value,list):return '['+', '.join(dumps(x,level+1) for x in value)+']'
    if isinstance(value,dict):
        return '{\n'+',\n'.join('  '*(level+1)+json.dumps(k,ensure_ascii=False)+': '+dumps(v,level+1) for k,v in sorted(value.items()))+'\n'+'  '*level+'}'
    raise WrapperError('TYPE','Unsupported JSON value '+type(value).__name__)

def dump(path,value):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x',encoding='utf-8') as f:f.write(dumps(value)+'\n')

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def semantic_sha(value):return hashlib.sha256(dumps(value).encode()).hexdigest()
def reference(path,pointer=''):
    p=Path(path);return {'file':str(p.relative_to(ROOT)) if ROOT in p.parents else str(p),'sha256':sha(p),'pointer':pointer}

def fresh_output(path, input_roots=()):
    raw=Path(path).absolute()
    if raw.is_symlink():raise WrapperError('OUTPUT_SYMLINK','Output itself is a symlink',[str(raw)])
    resolved=raw.resolve()
    for source in input_roots:
        s=Path(source).resolve()
        if resolved==s or resolved in s.parents or s in resolved.parents:
            raise WrapperError('OUTPUT_OVERLAP','Output overlaps preserved source',[str(resolved),str(s)])
    if resolved.exists():raise WrapperError('OUTPUT_EXISTS','Output must be a new directory; prior work is preserved',[str(resolved)])
    return resolved
