# Fixed bounded adapter contract

The sole supported scope is `bounded_non_voltage_synthetic`, with exactly `voltage` excluded. The wrapper does not assert any manufacturer tolerance interval. Generated camera records have `supply_range_V: null`. Source supply statements remain in the ledger as excluded evidence with their original nominal/operating-option class and power-path qualifications.

The ten retained runtime files are unchanged. `tools/bounded_adapter.py` temporarily wraps the retained module's `evaluate` function in its own CLI process, restoring it in a `finally` block. It first calls the original evaluator, requires its voltage row to be unknown, retains that row as excluded evidence, and removes exactly that row from the bounded constraint summary. Failure-before-unknown is recomputed over the remaining unchanged rows. No equation, interval calculation, cost rule, U01 rule, source resolver, guarantee standard, simulation method or numeric-encoding guard is replaced.

This limited interface adapter is not a general constraint plugin or a concurrency-safe embedding API. A full-system reader must not consume bounded `feasible_plan` as hardware compatibility. Scope labels travel with selected and hypothetical plans, current decisions and outer envelopes. `R-VOLT` is excluded from active rule lists. Hardware revalidation still needs voltage resolution. Calling the ordinary retained CLI on the generated case continues to treat voltage as unknown.

For positive speed, the retained timing inequality is:

`speed * (abs(timestamp_bias + offset) + camera_jitter_bound + host_jitter_bound) <= error_limit`

The compatible FLIR scenario has zero bias in both variants. Fast gives `J <= 1/2 - 1/10 = 2/5 ms`; slow gives `J <= (1/2)/(1/2) - 1/10 = 9/10 ms`. The shared and per-variant threshold is therefore 2/5 ms, inclusive, when all other **in-scope** constraints are established. No change was made to that derivation. New input parsing uses Decimal-to-Fraction conversion with bounded token/exponent sizes and exact finite-decimal serialization before the retained parser. Display floats produced after a decision are not reused as evidence inputs. `NumericEncodingError` remains distinct from invalid input or physical impossibility.

The gate consumes only the scenario, ledger and supporting captures. It does not consume `expected`, `intended_verdict`, golden outcomes or reviewer verdicts. Its finite premise vocabulary covers Mono8 byte size, resolution context, transport, compression, timestamp event, additive versus scale/drift clock behavior, usable payload budgeting, source-qualified camera mode and relevant power path. Unsupported physics yields OUTSIDE_MODEL or an explicitly bounded refusal. Unknown camera mode withholds qualified facts; it cannot inherit the fastest row. This is not automatic recognition of all real-world assumptions.

The canonical ledger stores source/capture identity, exact lexical and normalized values, units, class, conditions, locators, reasons and destinations or quarantine. Supporting capture payloads are pinned by content identity. Transfer checks bind subject/field/destination, source identity, normalization and required qualifiers. Applicable unequal admitted values produce a classified conflict with both references. Explicit units must match the fixed retained field contract; no conversion is performed. Nonquantitative fields say `not_applicable`. The two supplied test metrics are registration error in mm; this is not a generic metric-unit resolver. Typical/sample/nominal evidence cannot fill a guaranteed/max power or jitter slot; no exception rule was adopted. Equal facts retain all supporting origins and conditions.

Source authenticity and correctness of human adjudication remain external responsibilities. An actor who edits the entire ledger, source captures and their identities coherently can author new false premises; hashes do not confer truth, permission or authority. No signature, authenticated vendor feed, OCR or autonomous admission is implemented.

Tests are projected as `test_record`, with configuration nested under `data.configuration`. Both declared tests must reach the audit even if no plan is selected. An internal PASS contradiction is separate from stale applicability; a finite sample never becomes a guaranteed bound.

The jitter question points to synthetic integration characterization and the integration owner. A published vendor guarantee is not presumed, and a valid guarantee may be unavailable. If the necessary semantics cannot be established, retain unknown or refuse the model rather than fabricate evidence.

## v0.1.2 condition and applicability rules

The condition keys are a closed vocabulary.
- Executable prerequisites: `mode`, `premises`, `minimum_payload_MB_s`.
- Annotations (text only, never enforced): `source_wording_qualification`, `power_path_qualification`, `packaging_scope`, `scenario`.
- Any other key refuses the ledger with `UNRECOGNIZED_CONDITION`. Nothing is corrected or inferred.

Each admitted row is classified as APPLICABLE, INAPPLICABLE (an established unmet condition) or UNRESOLVED before aggregation. Only applicable rows form a value, and only applicable unequal values conflict. An unresolved row that states a different value withholds the field (`UNRESOLVED_ALTERNATE`). A qualifier applies only to the source claim it qualifies. For example, the Allied ≥ 200 MByte/s condition belongs to the frame-rate row, not to the dimensions. See CHANGES_v0.1.2.md.
