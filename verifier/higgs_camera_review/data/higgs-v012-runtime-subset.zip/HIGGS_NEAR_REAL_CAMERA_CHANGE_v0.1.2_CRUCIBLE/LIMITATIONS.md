# Remaining limitations

- Bounded, fictional non-voltage analysis only. Voltage is unknown/excluded for every candidate; no full replacement suitability or deployment approval follows.
- Manufacturer documents were checked during Round 1. This correction uses those pinned captures and recorded source checks; it does not claim another live vendor verification. Sources may change. Full copyrighted vendor pages/PDFs are not redistributed.
- Basler's original 160-fps product capture is quarantined because its configuration is not reconciled with the current documentation's 164-fps default-setting statement. Default resolution is labeled as default, not full sensor size. Basler therefore has additional unresolved frame-rate evidence as well as typical-only power.
- The originally named Allied bare-board datasheet was not recovered at its URL. Its historical captures remain quarantined. Selected general-model dimension/rate fields come from the separately identified official alternate PDF recovered during Round 1; this is not authentication of the missing document or qualification of a particular housing/thermal variant.
- FLIR mode/firmware premises are explicit synthetic declarations matching a selected published table row. They are not proof of real configured settings, exposure/trigger performance or sustained frame rate. Typical versus maximum power and the power path remain material.
- Real timing semantics, clock chains, temperature, startup/inrush power, optics, exposure, transport overhead beyond the declared usable budget and other omitted physics are not newly modeled. A source bound cannot repair a model that does not represent the relevant behavior.
- The synthetic integration jitter guarantee may be unobtainable. Finite observations and model-written PASS statements do not establish it.
- Source/supporting capture hashes detect incoherent edits within the declared boundary, not a coherent fabrication of the whole evidence package. Human adjudication and primary-source meaning still require review.
- One ledger replaces the three parallel decision/capture projections. Immutable capture support and generated projections remain necessary representations, not competing admission authorities. Whether this is better than a conventional worksheet is unmeasured.
- U01 policy A remains. Cosmetic active-record conflicts may prevent selection; policy B, automated relevance and record-splitting architecture are deferred.
- The bounded adapter is a fixed single-process interface wrapper, not a general plugin architecture or concurrency-safe service API.
- Validation is author testing, not Round-2 approval. Preimplementation expectations were independently derived from equations/source conditions but authored by the implementer. Round-1 reviews were separate and nonblind, with historical lineage overlap.
- Test groups, CLI calls, smoke checks and repeated runs overlap. Only the platform/interpreter named in actual records was exercised. This is not exhaustive fuzzing, general engineering correctness or a statistical reliability estimate.
- No customer validation, willingness to pay, ROI, measured savings, vendor endorsement, regulatory compliance, hardware qualification, production readiness or demonstrated CogniMap superiority.
- Deferred by the work order: OCR/PDF automation, new vendors/families/physics, U01 B, report/UI redesign, customer workflows, PLM/Jira, authentication, cloud services, probabilistic confidence and enterprise infrastructure. The provenance appendix is a correction, not a new report product.

Nothing in this candidate authorizes publication, GitHub/Atlas changes, hardware operation or contacting a reviewer.

v0.1.2: an unresolved alternate row with a different value withholds a field that an applicable row would otherwise supply. This is deliberately conservative and can yield `unsupported` where a human might resolve the alternate. Annotation text is never evaluated, so a prerequisite written only in an annotation is not enforced; an adjudicator must encode it as an executable condition. Coherent false source content (Round-2 P21/P22) still passes the internal checks.
